import React, {useState, useEffect} from 'react'
import {Modal} from 'antd';
import Loader from 'react-loader-spinner'
import {
    Button,
    Form,
    FormGroup,
    Label,
    FormText,
    InputGroup,
    InputGroupAddon,
    InputGroupText,
    Input,
  } from "reactstrap";
  import {
	CCard,
	CCardBody,
	CCardHeader,
	CCarousel,
	CCarouselCaption,
	CCarouselControl,
	CCarouselIndicators,
	CCarouselInner,
	CButton,
	CCarouselItem,
	CCol,
	CRow,
  } from "@coreui/react";
export default function Header(props) {
    const [reg1, setReg] = useState(true)
    const [reg2, setReg2] = useState(false)

    const prev = () => {
        setReg(true)
        setReg2(false)
    }

    const next = () => {
        setReg(false)
        setReg2(true)
    }

    
    return (
        <header className="header ">
        <div className="container">
            <div className="row flexbox-center">
                <div className="col-lg-2 col-md-3 col-6">
                    <div className="mt-0" style={{background:'white'}}>
                        <a href="/"><img src={require('../../img/cititrust_financial.png')} alt="logo" width="80%" /></a>
                    </div>
                </div>
                <div className="col-lg-10 col-md-9 col-6">
                    <div className="responsive-menu"></div>
                    <div className="mainmenu">
                        <ul id="primary-menu">
                            {/* <li><a className="nav-link" href="home">Home</a></li> */}
                            <li><a className="nav-link " href="#services">Services</a></li>
                            <li><a className="nav-link " href="#">About </a></li>
                            <li><a className="nav-link " href="#faqs">Faqs</a></li>
                            <li><a className="nav-link " href="/login">Sign In</a></li>
                            <li><a className="nav-link active " href="/register"  >Sign Up</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
    </header>
    )
}
