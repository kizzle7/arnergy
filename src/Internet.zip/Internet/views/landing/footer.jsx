import React from 'react'

export default function Footer() {
    return (
      <footer style={{ background: "#017DC3", color: "white"}}>
      <div class="container">
        <div class="row">
          <div class="col-sm-8 col-md-6">
            <div class="available-store">
              <a class="btn btn-platform mr-5" style={{ background: "#000" }}>
                <span
                  class="fa fa-play"
                  style={{ background: "#000" }}
                ></span>
                <em> Available on </em> play store
              </a>{" "}
              <a class="btn btn-platform" style={{ background: "#000" }}>
                <span class="fa fa-apple"></span>
                <em> Available on </em> App store
              </a>
            </div>
          </div>
          <div class="col-sm-4 col-md-6">
            <div class="subscribe-box" style={{background: 'white', }}>
              <p>
                <img src={require("../../img/cititrust_financial.png")} width="20%" />
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="copyright">
            <div class="col-sm-4 col-md-4">
              <p>
                <span class="hidden-sm">Copyright</span> &copy; CreditGo Africa. All
                Rights Reserved.
              </p>
            </div>
            <div class="col-sm-4 text-center">
              <ul class="inline-menu list-unstyled text-white">
                <li>
                  <a class="inline-menu-item text-white" href="#">
                    Contact
                  </a>
                </li>
                <li>
                  <a class="inline-menu-item text-white" href="#">
                    Sitemap
                  </a>
                </li>
                <li>
                  <a class="inline-menu-item text-white" href="#">
                    Terms
                  </a>
                </li>
                <li>
                  <a class="inline-menu-item text-white" href="#">
                    Privacy
                  </a>
                </li>
              </ul>
            </div>
            <div class="col-sm-4 col-md-4">
              <ul class="social-links text-right">
                <li>
                  <a href="#" class="ico-facebook">
                    <span class="fa fa-facebook"></span>
                  </a>
                </li>
                <li>
                  <a href="#" class="ico-twitter">
                    <span class="fa fa-twitter"></span>
                  </a>
                </li>
                <li>
                  <a href="#" class="ico-google-plus">
                    <span class="fa fa-google-plus"></span>
                  </a>
                </li>
                <li>
                  <a href="#" class="ico-linkedin">
                    <span class="fa fa-linkedin"></span>
                  </a>
                </li>
                <li>
                  <a href="#" class="ico-instagram">
                    <span class="fa fa-instagram"></span>
                  </a>
                </li>
                <li>
                  <a href="#" class="ico-youtube">
                    <span class="fa fa-youtube"></span>
                  </a>
                </li>
              </ul>
            </div>
            <div class="clearfix"></div>
         
          </div>
        </div>
      </div>
    </footer>
    )
}
