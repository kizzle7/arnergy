import React, { useState, useEffect } from "react";
import Header from './header'
import Footer from './footer'
import {
	CCardBody,
	CCarousel,
	CCarouselCaption,
	CCarouselControl,
	CCarouselIndicators,
	CCarouselInner,
	CButton,
  CCarouselItem,
    
    CCard,
    CCardHeader,
    CFormGroup,
    CLabel,
    CSelect,
    CFormText,
    CForm,
    CInput,
    CInputFile,

	CCol,
	CRow,
  } from "@coreui/react";
  import Cookie from 'js-cookie'
import {
	Card, CardImg, CardText, CardBody,
	CardTitle, CardSubtitle, Button, FormGroup, Input, Label, Alert
  } from 'reactstrap';
  import {Modal} from 'antd'
import { FlexibleHeightXYPlot } from "react-vis";
import Loader from 'react-loader-spinner'
import './css/bootstrap.min.css'
export default function Landing(props) {

  const [loan, setLoan] = useState(false)
  const [first, setFirst] = useState(true)
  const [load, setLoad] = useState(false)
  const [check, setCheck] = useState(false)




 const nextbank = () => {
   setLoad(true)
   setFirst(false)
   setTimeout(() => {
     setLoad(false)
     setCheck(true)
   }, 2000)

 }

const loanStart = (e) => {
  e.preventDefault()
  setLoan(true)
}

const proceed = () => {
  Cookie.set('loan', 90)
  window.location.replace('/login');

}

const cancelLoan = () => {
  setLoan(false)
}




  return (
    <>
    <div>

      <Header />
    
    
     

      <section class="hero-area" id="home">
        <div class="container">
          <div class="row">
            <div class="col-lg-7">
              <div class="hero-area-content">
                <h1 className="" style={{ fontSize: "32px" }}>
                  CitiTrust Financial Internet Banking.
                </h1>
                <p style={{ fontSize: "16px", fontStyle: 'italics' }}>
                  <i>serving all your financials online</i>
                </p>
                <a class="btn btn-lg btn-default" href="" onClick={loanStart}>Get Started</a>


                <div class="available-store pt-5">
                  <a
                    class="btn btn-platform pr-5"
                    style={{ background: "#000" }}
                  >
                    <span class="fa fa-play pr-3"></span>
                    <em className="pr-5"> Available on </em> PLAY STORE
                  </a>{" "}
                  <a class="btn btn-platform" style={{ background: "#000" }}>
                    <span class="fa fa-apple"></span>
                    <em> Available on </em> App store
                  </a>
                </div>
                <br />
                <br />
              </div>
            </div>

            <div class="col-lg-5 mt-0">
			
      <div class="hand-mockup text-lg-left text-center pt-0 mt-0">

        <img
          src={require("../../img/tt.png")}
          alt="Hand Mockup"
          className="w-50"
          width="100%"
          style={{marginBottom: '.1rem', marginTop: '14rem'}}
        />

</div>
    </div>

            
         
          </div>
        </div>
      </section>
      {/* <section id="publisher-container">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <CCarousel animate className="container">
                <CCarouselInner>
                  <CCarouselItem>
                    <ul class="featured-logo">
                      <li class="hidden-xs">
                        <span className="ml-5">Our Partners</span>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/1.png")}
                            style={{ maxWidth: "7rem", minWidth: "8rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/2.png")}
                            style={{ maxWidth: "7rem", minWidth: "3rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/3.png")}
                            style={{
                              maxWidth: "10rem",
                              minWidth: "8rem",

                            }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/4.png")}
                            style={{ maxWidth: "8rem", minWidth: "8rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/5.png")}
                            style={{ maxWidth: "8rem", minWidth: "8rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/6.png")}
                            style={{ maxWidth: "8rem", minWidth: "8rem" }}
                          />
                        </a>
                      </li>
                    </ul>
                  </CCarouselItem>
                  <CCarouselItem>
                    <ul class="featured-logo">
                      <li class="hidden-xs">
                        <span className="ml-5">Our Partners</span>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/lua.png")}
                            style={{ maxWidth: "10rem", minWidth: "10rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/lua.png")}
                            style={{ maxWidth: "10rem", minWidth: "10rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/lua.png")}
                            style={{ maxWidth: "10rem", minWidth: "10rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/lua.png")}
                            style={{ maxWidth: "10rem", minWidth: "10rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/lua.png")}
                            style={{ maxWidth: "10rem", minWidth: "10rem" }}
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img
                            class="img-responsive"
                            src={require("../../img/lua.png")}
                            style={{ maxWidth: "10rem", minWidth: "10rem" }}
                          />
                        </a>
                      </li>
                    </ul>
                  </CCarouselItem>
                </CCarouselInner>
                <CCarouselControl direction="prev" className="text-info" />
                <CCarouselControl direction="next" />
              </CCarousel>
            </div>
          </div>
        </div>
      </section> */}

      <section
        id="services"
        class="padding-2x"
        style={{ background: "whitesmoke" }}
      >
        <div class="container">
          <div class="row">
            <div class="col-md-6 col-md-offset-3">
              <div class="section-heading text-center">
                <h2 class="font-weight-bold" style={{ fontSize: "30px" }}>
                  Our Services
                </h2>
                <p>
                  Cititrust financial enables individuals to access quick loans,
                  send money, receive funds, buy airtime, pay bills and shop
                  globally with our CreditGo Card.
                </p>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-4 col-md-4">
              <div class="box-content text-center">
                <div class="block-icon">
                  <img src={require("../../img/007-museum.png")} width="20%" />
                </div>
                <h3>Instant Loan</h3>
                <p>
                  {" "}
                  We empower individuals with access to quick loans at
                  affordable interest rate..
                </p>
              </div>
            </div>
            <div class="col-sm-4 col-md-4">
              <div class="box-content text-center">
                <div class="block-icon">
                  <img src={require("../../img/002-money.png")} width="20%" />
                </div>
                <h3>Send Money</h3>
                <p>
                  With CreditGo Africa you can transfer your disbursed loan to
                  other bank account or mobile wallets within Africa.
                </p>
              </div>
            </div>
            <div class="col-sm-4 col-md-4">
              <div class="box-content text-center">
                <div class="block-icon">
                  <img src={require("../../img/001-wallet.png")} width="20%" />
                </div>
                <h3>Recieve Fund</h3>
                <p>
                  After onboarding as a CreditGo Africa customer, you will be
                  able to receive fund into your wallet from any bank account.
                </p>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-4 col-md-4">
              <div class="box-content no-border text-center">
                <div class="block-icon">
                  <img src={require("../../img/005-call.png")} width="20%" />
                </div>
                <h3>Buy Airtime</h3>
                <p>
                  You can instantly buy airtime from any telco with CreditGo
                  Africa.
                </p>
              </div>
            </div>
            <div class="col-sm-4 col-md-4">
              <div class="box-content no-border text-center">
                <div class="block-icon">
                  <img
                    src={require("../../img/001-tv-monitor.png")}
                    width="20%"
                  />
                </div>
                <h3>Pay Bills</h3>
                <p>
                  With CreditGo Africa you can conveniently pay bills for PHCN,
                  DSTV, GOTV, Spectranet, Ntel & Smile e.t.c from any country..
                </p>
              </div>
            </div>
            <div class="col-sm-4 col-md-4">
              <div class="box-content no-border-last text-center">
                <div class="block-icon">
                  <img
                    src={require("../../img/006-credit-card.png")}
                    width="20%"
                  />
                </div>
                <h3>CreditGo Card</h3>
                <p>
                  Using CreditGo Mastercard linked your wallet, you can easily
                  make payment Online, POS, ATM in any country..
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="platform">
        <div class="container padding-2x">
          <div class="row">
            <div class="col-md-6 col-md-offset-3">
              <div class="section-heading text-center">
                <h2 style={{ fontSize: "30px" }} className="text-info">
                  Cititrust Financial App
                </h2>
                <p>
                  The CreditGo App is currently available on the Google
                  PlayStore and App Store.
                </p>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
              <div class="platform-img">
                <img
                            src={require("../../img/tt.png")}
                  alt="Hand Mockup"
                  className="img-responsive"
                  width="60%"
                />
              </div>
            </div>
            <div class="col-sm-6">
              <div class="medium-list">
                <ul class="tab-list">
                  <li class="hidden-sm">
                    <div class="medium">
                      <div class="medium-left">
                        <img
                          src={require("../../img/007-museum.png")}
                          width="100%"
                        />
                      </div>
                      <div class="medium-body">
                        <h4 class="medium-heading">Apply For Loan</h4>
                        <p>
                          {" "}
                          We empower individuals with access to quick loans at
                          affordable interest rate.
                        </p>
                      </div>
                    </div>
                  </li>
                  <li class="">
                    <div class="medium">
                      <div class="medium-left">
                        <img
                          src={require("../../img/001-wallet.png")}
                          width="100%"
                        />
                      </div>
                      <div class="medium-body">
                        <h4 class="medium-heading">Fund Wallet</h4>
                        <p>
                          Fund your wallet from any debit card or from any bank
                          account.
                        </p>
                      </div>
                    </div>
                  </li>
                  <li class="">
                    <div class="medium">
                      <div class="medium-left">
                        <img
                          src={require("../../img/002-money.png")}
                          width="100%"
                        />
                      </div>
                      <div class="medium-body">
                        <h4 class="medium-heading">Send Money</h4>
                        <p>
                          With CreditGo Africa you can transfer your disbursed
                          loan to other bank account or mobile wallets within
                          Africa .
                        </p>
                      </div>
                    </div>
                  </li>

                  <li class="hidden-sm">
                    <div class="medium">
                      <div class="medium-left">
                        <img
                          src={require("../../img/005-call.png")}
                          width="100%"
                        />
                      </div>
                      <div class="medium-body">
                        <h4 class="medium-heading">Buy Airtime</h4>
                        <p>
                          {" "}
                          You can instantly buy airtime from any telco with
                          CreditGo Africa.
                        </p>
                      </div>
                    </div>
                  </li>
                  <li class="hidden-sm">
                    <div class="medium">
                      <div class="medium-left">
                        <img
                          src={require("../../img/004-love-message.png")}
                          width="100%"
                        />
                      </div>
                      <div class="medium-body">
                        <h4 class="medium-heading">Buy Data Bundle</h4>
                        <p>
                          {" "}
                          You can instantly buy data bundle from any telco with
                          CreditGo Africa.
                        </p>
                      </div>
                    </div>
                  </li>
                  <li class="hidden-sm">
                    <div class="medium">
                      <div class="medium-left">
                        <img
                          src={require("../../img/006-credit-card.png")}
                          width="100%"
                        />
                      </div>
                      <div class="medium-body">
                        <h4 class="medium-heading">Request CreditGo Card</h4>
                        <p>
                          Using CreditGo Mastercard linked your wallet, you can
                          easily make payment Online, POS, ATM in any country.
                        </p>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="faqs" class="grey-bg padding-2x">
        <div class="container">
          <div class="row">
            <div class="col-md-6 col-md-offset-3">
              <div class="section-heading text-center">
                <h2 style={{ fontSize: "30px" }}>Frequently Asked Question</h2>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
              <div id="accordion" class="faq-block">
                <div class="panel accordion-panel">
                  <h4 class="faq-heading">
                    <a
                      class="accordion-toggle"
                      data-toggle="collapse"
                      data-parent="#accordion"
                      href="#collapseOne"
                      aria-expanded="false"
                      style={{fontSize: '14px', textDecoration: 'none'}}
                    >
                      Q:What is CreditGo Africa?
                    </a>
                  </h4>
                  <div id="collapseOne" class="accordion-body collapse">
                    <p>
                      CreditGo Africa is an online lending service and does not
                      operate via physical branches. This service is provided by
                      CitiTrust Holdings PLC and its subsidiaries, a licensed
                      and regulated finance company.
                    </p>
                  </div>
                </div>
                <div class="panel accordion-panel">
                  <h4 class="faq-heading">
                    <a
                      class="accordion-toggle"
                      data-toggle="collapse"
                      data-parent="#accordion"
                      href="#faqtwo"
                      style={{fontSize: '14px', textDecoration: 'none'}}

                      aria-expanded="false"
                    >
                      Q: Approved Identification Documents?
                    </a>
                  </h4>
                  <div id="faqtwo" class="accordion-body collapse">
                    <p>
                      We only accept valid government-approved identification
                      cards and this includes:</p>
					  <ul>
						  <li>1. International passport Permanent</li>
						  <li>2. Drivers license</li>
						  <li>3. Permanent voters card (PVC)</li>
						  <li>4. National ID
                      card, plastic, and slip (NIMC)</li>
						</ul>    
                  
                  </div>
                </div>
                <div class="panel accordion-panel">
                  <h4 class="faq-heading">
                    <a
                      class="accordion-toggle"
                      data-toggle="collapse"
                      data-parent="#accordion"
                      href="#faqthree"
                      aria-expanded="false"
                      style={{fontSize: '14px', textDecoration: 'none'}}

                    >
                      Q: What is OTP?
                    </a>
                  </h4>
                  <div id="faqthree" class="accordion-body collapse">
                    <p>
					One-time PIN [OTP] Ensure you do not leave the card setup page to check your inbox. You can simply check the content of the SMS verification bar on your phone.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div id="accordion-2" class="faq-block">
                <div class="panel accordion-panel">
                  <h4 class="faq-heading">
                    <a
                      class="accordion-toggle"
                      data-toggle="collapse"
                      data-parent="#accordion-2"
                      href="#faqfour"
                      aria-expanded="false"
                      style={{fontSize: '14px', textDecoration: 'none'}}

                    >
                      Q: How to get a CreditGo Africa Loan??
                    </a>
                  </h4>
                  <div id="faqfour" class="accordion-body collapse">
                    <p>
					Sign in or sign up to identify yourself and this will take you to our brief registration/application forms in our web or mobile platform . Complete an application with valid information and click on “apply for loan”, then state how much you would like to borrow. We will then display your available loan offer in the app and you can view your expected repayment(s). Submit your application and we will typically notify you of the loan decision within minutes.
                    </p>
                  </div>
                </div>
                <div class="panel accordion-panel">
                  <h4 class="faq-heading">
                    <a
                      class="accordion-toggle"
                      data-toggle="collapse"
                      data-parent="#accordion-2"
                      href="#faqfive"
                      aria-expanded="false"
                      style={{fontSize: '14px', textDecoration: 'none'}}

                    >Q:How do I repay my loan? </a>
                  </h4>
                  <div id="faqfive" class="accordion-body collapse">
                    <p>
					We have made repaying your loan on CreditGo Africa as easy as possible.  On your due date(s), your payment will conveniently be deducted from the account linked to the debit/ATM card provided during your loan application or your CreditGo wallet. 

                    </p>
                  </div>
                </div>
               
              </div>
            </div>
          </div>
        </div>
      </section>
      </div>

      
      

      <Footer />

      <Modal
        title="Loan Application"
        visible={loan}
        onCancel={cancelLoan}
        footer={false}
        centered={true}
        centered={true}
        width={650}
        

      >
           <div>            {first &&
                              <CForm
                                action=""
                                method="post"
                                encType="multipart/form-data"
                                className="form-horizontal"
                              >
                                <CFormGroup row>
                                  <CCol md="4">
                                    <CLabel className="font-weight-bold">How much do you want?</CLabel>
                                  </CCol>
                                  <CCol md="8">
                                    <CInput
                                      type="email"
                                      id="email-input"
                                      name="email-input"
                                      autoComplete="email"
                                    />
                                  </CCol>
                                </CFormGroup>
                                <CFormGroup row>
                                  <CCol md="4">
                                    <CLabel htmlFor="text-input" className="font-weight-bold">Tenure</CLabel>
                                  </CCol>
                                  <CCol md="8">
                                    <CSelect custom name="select" id="select" style={{height: '3.3rem', fontSize: '14px'}}>
                                      <option value="0">Please select</option>
                                      <option value="1">2 Months</option>
                                      <option value="2">3 Months</option>
                                      <option value="2">4 Months</option>
                                      <option value="2">5 Months</option>
                                      <option value="2">6 Months</option>
                                      <option value="2">7 Months</option>
                                      <option value="2">8 Months</option>
                                      <option value="2">9 Months</option>
                                      <option value="2">10 Months</option>
                                      <option value="2">11 Months</option>
                                      <option value="2">12 Months</option>
                                    </CSelect>
                                  </CCol>
                                </CFormGroup>

                                <CFormGroup row>
                                  <CCol md="4">
                                    <CLabel htmlFor="email-input" className="font-weight-bold">
                                      Reason for taking loan?
                                    </CLabel>
                                  </CCol>
                                  <CCol md="8">
                                    <CSelect custom name="select" id="select" style={{height: '3.3rem', fontSize: '14px'}}>
                                      <option value="0">Please select</option>
                                      <option value="1">Education</option>
                                      <option value="2">Medical</option>
                                      <option value="2">Rent</option>
                                      <option value="2">Travel</option>
                                      <option value="2">Bussiness</option>
                                      <option value="2">Events</option>
                                      <option>household</option>
                                      <option>Other</option>
                                    </CSelect>
                                  </CCol>
                                </CFormGroup>
                                <div className="text-right">
                                  <CButton
                                    size="md"
                                    color="dark"
                                    onClick={nextbank}
                                  >
                                    Next
                                  </CButton>
                                </div>
                              </CForm>}
                            </div>
                            {load && (
                            <div className="pb-5">
                              <h4 className="font-weight-bold  text-center text-dark pb-3 ">
                                Calculating Loan
                              </h4>
                              <Loader
                              className="pt-5 pb-5"
                                type="TailSpin"
                                className="text-center"
                                height={60}
                                width={60}
                              />
                            </div>
                          )}

      </Modal>

      <Modal
            title={"Loan Application Success"}
            visible={check}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
            centered={true}
          >
            <div>
              <Alert color="success">
                <h4 className="alert-heading">Congrats!</h4>
                <p>Dear Customer, we are delightful to inform you that your loan offer was acknowledged, Please kindly Sign In/ Sign Up to proceed to complete your loan application.</p>
                <hr />
                <div className="text-right">
                  <CButton
                    size="md"
                    color="info"
                    className="text-right"
                    onClick={proceed}
                  >
                    Proceed
                  </CButton>
                </div>
              </Alert>
            </div>
          </Modal>
    </>
  );
}
