import React from 'react';
import {
    CRow,
    CCol,
    CCard,
    CCardBody,
    CCardHeader,
    CDropdown,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CNav,
    CNavItem,
    CFormGroup,
    CForm,
    CLabel,
    CInput,
    CFormText,
    CSelect,
    CTextarea,
    CNavLink,
    CCardFooter,
    CButton
  } from '@coreui/react'
  import {Card } from 'reactstrap'

 import WidgetsBillCategory from '../widgets/WidgetsBillCategory.js'
 import WidgetsWidgetsCableTV from '../widgets/WidgetsCableTV.js'
 import WidgetsUtilityBill from '../widgets/WidgetsUtilityBill.js'
 import WidgetsInternetPlan from '../widgets/WidgetsInternetPlan.js'
 import WidgetsTaxes from '../widgets/WidgetsTaxes.js'
 import WidgetsSchool from '../widgets/WidgetsSchool.js'
 
 
class BillPayment extends React.Component{
  state = {
    cable:true,
    utility: false,
    internet:false,
    taxes: false,
    schools: false,
    flights: false
  }
  cable = () => {
    this.setState({cable:true, utility:false, internet:false, taxes:false, schools:false, flights:false})
  }
  utility = () => {
    this.setState({cable:false, utility:true, internet:false, taxes:false, schools:false, flights:false})
  }

  internet = () => {
    this.setState({cable:false, utility:false, internet:true, taxes:false, schools:false, flights:false})

  }

  taxes = () => {
    this.setState({cable:false, utility:false, internet:false, taxes:true, schools:false, flights:false})

  }

  schools =() => {
    this.setState({cable:false, utility:false, internet:false, taxes:false, schools:true, flights:false})

  }

  flights = () => {
    this.setState({cable:false, utility:false, internet:false, taxes:false, schools:false, flights:true})

  }
    render(){
        return(
            <>
          
          <CRow>
              <CCol sm="12" md="12">
                <CCard>
                  <CCardHeader>
                  <small className="font-weight-bold">Bill Category</small>
                  </CCardHeader>
                  <CCardBody>
                  <CRow>
      
      <CCol sm="4" lg="2">
      <Card className="point" onClick={this.cable}>
        <div className="text-center">
        {this.state.cable ? <img src={require('../../img/transfer.png')} width="15%" className="pt-5 mb-1 text-info" />: <img src={require('../../img/transfer.png')} width="15%" className="pt-3 text-info" />}
        <p className="font-weight-bold text-center" >Cable TV</p>
        </div>
     
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card className="point" onClick={this.utility}>
        <div className="text-center">
        {this.state.utility ? <img src={require('../../img/loans.png')} width="15%" className="pt-5 mb-1" /> : <img src={require('../../img/loans.png')} width="15%" className="pt-3" />}
        <p className="font-weight-bold text-center">Utility Bills</p>
        </div>

      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card className="point" onClick={this.internet}>
        <div className="text-center">
        {this.state.internet ? <img src={require('../../img/bill_payment.png')} width="15%" className="pt-5 mb-1" /> : <img src={require('../../img/bill_payment.png')} width="15%" className="pt-3" />}
        <p className="font-weight-bold text-center">Internet Plans</p>
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card className="point" onClick={this.taxes}>
        <div className="text-center">
        {this.state.taxes ? <img src={require('../../img/bill_payment.png')} width="15%" className="pt-5 mb-1" />: <img src={require('../../img/bill_payment.png')} width="15%" className="pt-3" />}
        <p className="font-weight-bold text-center">Taxes</p>
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card className="point" onClick={this.schools}>
        <div className="text-center">
        {this.state.schools ? <img src={require('../../img/buy_airtime.png')} width="15%" className="pt-5 mb-1" />: <img src={require('../../img/buy_airtime.png')} width="15%" className="pt-3" />}
        <p className="font-weight-bold text-center">Schools</p>
        </div>
   
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card className="point" onClick={this.flights}>
        <div className="text-center">
        {this.state.flights ? <img src={require('../../img/bill_payment.png')} width="15%" className="pt-5 mb-1" /> : <img src={require('../../img/bill_payment.png')} width="15%" className="pt-3" />}
        <p className="font-weight-bold text-center">Flights</p>
        </div>
      
      </Card>
      </CCol>

      
    </CRow>
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>
            {this.state.cable &&
            <CRow className="point">
              <CCol sm="12" md="12">
                <CCard className="point" >
                  <CCardHeader on>
                  <small className="font-weight-bold">Cable TV</small>
                  </CCardHeader>
                  <CCardBody >
                  <a href="#" className="point">
                  <WidgetsWidgetsCableTV /></a>
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>}

            {this.state.utility &&

            <CRow>
              <CCol sm="12" md="12">
                <CCard className="point" onClick={this.utility}>
                  <CCardHeader>
                  <small className="font-weight-bold">Utility Bills</small>
                  </CCardHeader>
                  <CCardBody>
                  <WidgetsUtilityBill />
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>}

            {this.state.internet &&
            <CRow>
              <CCol sm="12" md="12">
                <CCard onClick={this.internet}>
                  <CCardHeader>
                  <small className="font-weight-bold">Internet Plan</small>
                  </CCardHeader>
                  <CCardBody>
                  <WidgetsInternetPlan />
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>}

            {this.state.taxes &&
            <CRow>
            <CCol sm="12" md="12">
                <CCard >
                  <CCardHeader>
                  <small className="font-weight-bold">Taxes</small>
                  </CCardHeader>
                  <CCardBody>
                  <WidgetsTaxes />
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>}

            {this.state.schools &&
            <CRow>

              
            <CCol sm="12" md="12">
                <CCard >
                  <CCardHeader>
                  <small className="font-weight-bold">Schools</small>
                  </CCardHeader>
                  <CCardBody>
                  <WidgetsSchool />
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>}
            
            
            </>
        )
    }
}
export default BillPayment