import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsSchool = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/unilag.png')} width="40%" className="pt-3 pb-3 text-info" />
        </div>
     
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/lagosstateuniversity.jpg')} width="40%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/lagospoly.jpg')} width="40%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/covenantuniversity.jpg')} width="67%" className="pt-3 pb-3" />
        </div>
   
      </Card>
      </CCol>
      


      
    </CRow>
  )
}

export default WidgetsSchool
