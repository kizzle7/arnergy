import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsUtilityBill = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/ekedc.png')} width="73%" className="pt-3 pb-3 text-info" />
        </div>
     
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/ikedc.png')} width="37%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/eedc.png')} width="38%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/phedc.jpg')} width="75%" className="pt-3 pb-3" />
        </div>
   
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/aedc.jpg')} width="74%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/kedc.png')} width="74%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/jedc.jpg')} width="50%" className="pt-3 pb-3" />
        </div>
    
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/lawma.png')} width="69%" className="pt-3 pb-3" />
        </div>
    
      </Card>
      </CCol>


      
    </CRow>
  )
}

export default WidgetsUtilityBill
