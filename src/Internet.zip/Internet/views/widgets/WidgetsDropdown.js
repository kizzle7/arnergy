import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsDropdown = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/transfer.png')} width="30%" className="pt-3 text-info" />
        <p className="font-weight-bold text-center" >Fund Transfer</p>
        </div>
     
      </Card>
      </CCol>
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/loans.png')} width="30%" className="pt-3" />
        <p className="font-weight-bold text-center">Loan</p>
        </div>

      </Card>
      </CCol>
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/bill_payment.png')} width="32%" className="pt-3" />
        <p className="font-weight-bold text-center">Bill Payments</p>
        </div>
      
      </Card>
      </CCol>
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/buy_airtime.png')} width="33%" className="pt-3" />
        <p className="font-weight-bold text-center">Airtime Purchase</p>
        </div>
   
      </Card>
      </CCol>

      {/* <CCol sm="6" lg="3">
      <CWidgetDropdown
          color="gradient-info"
          header="Favourites"
          className="text-center"
          footerSlot={
            <i className="fa fa-star fa-4x pt-3 pb-3"></i>
          }
        >
          
        </CWidgetDropdown>
      </CCol>

      <CCol sm="6" lg="3">
      <CWidgetDropdown
          color="gradient-info"
          header="Bill Payments"
          className="text-center"
          footerSlot={
            <i className="fa fa-money fa-4x pt-3 pb-3"></i>
          }
        >
          
        </CWidgetDropdown>
      </CCol>

      <CCol sm="6" lg="3">
      <CWidgetDropdown
          color="gradient-info"
          header="Airtime Purchase"
          className="text-center"
          footerSlot={
            <i className="fa fa-mobile fa-4x pt-3 pb-3"></i>
          }
        >
          
        </CWidgetDropdown>
      </CCol> */}
    </CRow>
  )
}

export default WidgetsDropdown
