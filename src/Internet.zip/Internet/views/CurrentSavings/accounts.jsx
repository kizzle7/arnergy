import React from 'react';
import CNavbars from '../base/navbars/Navbars'
// import {Modal} from 'antd'
import {  CForm,CCol,  CLabel,CSelect,CButton,CCard, CCardHeader,
    CFormGroup,
    CRow,
    CCardBody,} from '@coreui/react'
import {Modal } from 'antd'
// import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

 class Account extends React.Component{
     state = {
         navbar : true,
         modal: true,
     }

     componentWillMount =() => {
 
     }

     viewTerminalclose = () =>  this.setState({modal: false})

     toggle = () => {
         this.setState({mode: !this.state.mode})
     }
     
     render(){
         return(
             <>
                  
                  <div>
                  {this.state.navbar && 
                 <div className="borderNav pt-2" style={{textDecoration: 'none'}}>
                   <a href="/account_detail" style={{textDecoration: 'none'}}><p className="pr-3 pl-3 text-warning">Account Details</p></a>
                     <a href="/view_statement" style={{textDecoration: 'none'}}><p className="pr-3 pl-3 text-white">View Statement</p></a>
                     <a href="/chequebook_request" style={{textDecoration: 'none'}}><p className="pr-3 text-white">Chequebook Request</p></a>
                     </div>}
                     <CRow>
                     <CCol md="12" >
          <CCard >
            <CCardHeader className="font-weight-bold">
              <div className="d-flex justify-content-between align-items-center">
                 
                      <p>CUSTOMER NAME- MICHEAL HARRY</p>
                      <p>ACCOUNT NUMBER- 090123344 </p>
              </div>
            </CCardHeader>
            
          </CCard>
        </CCol>

                     </CRow>

                     <CRow>
                     <CCol md="6" >
          <CCard >
            <CCardHeader className="font-weight-bold">
              Basic Informations
            </CCardHeader>
            <CCardBody>
                <div>
                    <p className="text-mute">Customer ID</p>
                    <p className="font-weight-bold">00487282628</p>

                </div>
                
                <div>
                    <p className="text-mute">Holding Pattern</p>
                    <p className="font-weight-bold">Single</p>

                </div>
                
                <div>
                    <p className="text-mute">Branch</p>
                    <p className="font-weight-bold">AJOSE ADEOGUN STREET , VICTORIA ISLAND, LAGOS</p>

                </div>
                <div>
                    <p className="text-mute">Status</p>
                    <p className="font-weight-bold">Active</p>

                </div>
                <div>
                    <p className="text-mute">BVN</p>
                    <p className="font-weight-bold">234367627848773737</p>

                </div>
                
            </CCardBody>
            
          </CCard>
        </CCol>
        <CCol md="6" >
          <CCard >
            <CCardHeader className="font-weight-bold">
              Balance Details
            </CCardHeader>
            <CCardBody>
                <div>
                    <p className="text-mute">Available Balance</p>
                    <p className="font-weight-bold">NGN 1479.320</p>

                </div>
                
                <div>
                    <p className="text-mute">Amount on Hold</p>
                    <p className="font-weight-bold">NGN 14595.32</p>

                </div>
                
             
                <div>
                    <p className="text-mute">Overdraft Limit</p>
                    <p className="font-weight-bold">NGN 200</p>

                </div>
                <div>
                    <p className="text-mute">Unclear Funds</p>
                    <p className="font-weight-bold">NGN 00</p>

                </div>
                <div>
                    <p className="text-mute">Advance Against Nuclear funds Limit</p>
                    <p className="font-weight-bold">234367627848773737</p>

                </div>
                
            </CCardBody>
            
          </CCard>
        </CCol>


                     </CRow>

                     
                     <CRow>
                     
                     </CRow>
                    
    



                 </div>

         
             </>
         )
     }
 }
 export default Account