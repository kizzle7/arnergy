import React from 'react';
import CNavbars from '../base/navbars/Navbars'
// import {Modal} from 'antd'
import {  CForm,CCol,  CLabel,CSelect,CButton,
    CFormGroup,} from '@coreui/react'
import {Modal } from 'antd'
// import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

 class Savings extends React.Component{
     state = {
         navbar : false,
         modal: true,
     }

     componentWillMount =() => {
         this.setState({modal: true})
         setTimeout(() => {
             this.setState({navbar: true})
         },1200)
     }

    //  viewTerminalclose = () =>  this.setState({modal: false})

     toggle = () => {
         this.setState({mode: !this.state.mode})
     }

     onChange = (e) => {
       if(e.target.value === "090123344 - Savings Account"){
         this.props.history.push('/account_detail')
       }
       else if(e.target.value === "018272837 - Current Account"){
         this.props.history.push('/account_detail')
       }
     }
     
     render(){
         return(
             <>
                  
                  <div>
            
                 <div className="borderNav pt-2" style={{textDecoration: 'none'}}>
                   <a href="/account_detail" style={{textDecoration: 'none'}}><p className="pr-3 pl-3 text-white">Account Details</p></a>
                     <a href="/view_statement" style={{textDecoration: 'none'}}><p className="pr-3 pl-3 text-white">View Statement</p></a>
                     <a href="/chequebook_request" style={{textDecoration: 'none'}}><p className="pr-3 text-white">Chequebook Request</p></a>
                     </div>

                     {/* <Button color="danger" onClick={this.toggle}>pres</Button> */}

                     <Modal
                    title={"Account Type"}
                    visible={this.state.modal}
                    onCancel={this.viewTerminalclose}
                    footer={null}
                    cancelText="Clear"
                    maskClosable={false}
                    centered={true}
                >
                    <CFormGroup row>
                  <CCol md="3">
                    <CLabel htmlFor="select">Select Account</CLabel>
                  </CCol>
                  <CCol xs="12" md="9">
                    <CSelect custom name="select" id="select" onChange={this.onChange}>
                      <option>Please select</option>
                      <option>090123344 - Savings Account</option>
                      <option>018272837 - Current Account</option>
                    </CSelect>
                  
                  </CCol>
                </CFormGroup>
                    
                   </Modal>
    



                 </div>

         
             </>
         )
     }
 }
 export default Savings