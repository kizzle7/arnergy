import React from 'react';
import CNavbars from '../base/navbars/Navbars'
// import {Modal} from 'antd'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow} from '@coreui/react'
import {Modal } from 'antd'
// import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

 class ChequeBook extends React.Component{
     state = {
         navbar : true,
     }

     componentWillMount =() => {
        
     }

     viewTerminalclose = () =>  this.setState({modal: false})

     toggle = () => {
         this.setState({mode: !this.state.mode})
     }
     
     render(){
         return(
             <>
                  
                  <div>
                 <div className="borderNav pt-2" style={{textDecoration: 'none'}}>
                   <a href="/account_detail" style={{textDecoration: 'none'}}><p className="pr-3 pl-3 text-white">Account Details</p></a>
                     <a href="/view_statement" style={{textDecoration: 'none'}}><p className="pr-3 pl-3 text-white">View Statement</p></a>
                     <a href="/chequebook_request" style={{textDecoration: 'none'}}><p className="pr-3 text-warning">Chequebook Request</p></a>
                     </div>

                     <CRow>
                     <CCol md="6" >
          <CCard >
            <CCardHeader className="font-weight-bold">
              ChequeBook Request
            </CCardHeader>
            <CCardBody>
                <div>
                    <p className="text-mute font-weight-bold">Account Number - 090123344 SAVINGS ACCOUNT</p>
                    <p className="text-mute">Balance - NGN15000</p>

                </div>
                
                
                
            </CCardBody>
            
          </CCard>
        </CCol>
        
        </CRow>
        <CRow>
        <CCol md="6" >
          <CCard >
            <CCardHeader className="font-weight-bold">
              ChequeBook Request Application Form
            </CCardHeader>
           
            <CCardBody>
              <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
               
                <CFormGroup>
                    <CLabel htmlFor="text-input">Number of Leaves Per Book</CLabel>
                    <CSelect custom name="select" id="select">
                      <option value="0">Please select</option>
                      <option value="1">Chequebooks with 25 Leaves</option>
                      <option value="2">Chequebooks with 50 Leaves</option>
                      <option value="3">Chequebooks with 100 Leaves</option>
                    </CSelect>                
                    </CFormGroup>
                
               
                <CFormGroup>
                
                    <CLabel htmlFor="select">City</CLabel>
                 
                  
                    <CSelect custom name="select" id="select">
                      <option value="0">Please select</option>
                      <option value="1">Lagos</option>
                      <option value="2">Ogun</option>
                      <option value="3">Ibadan</option>
                    </CSelect>
               
                </CFormGroup>
                <CFormGroup>
                
                    <CLabel htmlFor="select">Branch Near Me</CLabel>
                
                    <CSelect custom name="select" id="select">
                      <option value="0">Please select</option>
                      <option value="1">Lagos</option>
                      <option value="2">Ogun</option>
                      <option value="3">Ibadan</option>
                    </CSelect>
               
                </CFormGroup>
                <CFormGroup>
                <CLabel htmlFor="select">Delivery Location</CLabel>

                <CFormGroup variant="checkbox">
                      <CInputRadio className="form-check-input" id="radio3" name="radios" value="option3" />
                      <CLabel variant="checkbox" htmlFor="radio3">Branch Near Me</CLabel>
                    </CFormGroup>
                </CFormGroup>
               
              </CForm>
            </CCardBody>
            <CCardFooter>
              <CButton type="submit" size="md" color="dark">Submit</CButton>
            </CCardFooter>
          </CCard>
        </CCol>
                
                
             
        </CRow>
          
    



                 </div>

         
             </>
         )
     }
 }
 export default ChequeBook