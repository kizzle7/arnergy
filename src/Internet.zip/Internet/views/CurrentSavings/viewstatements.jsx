import React from 'react';
import CNavbars from '../base/navbars/Navbars'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow
  } from '@coreui/react'
import {Modal } from 'antd'
import { DatePicker } from 'antd';
import MUIDataTable from "mui-datatables";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
const { RangePicker } = DatePicker;
 class ViewStatement extends React.Component{
     state = {
         navbar : true,
         modal: true,
     }

     componentWillMount =() => {
        
     }

     viewTerminalclose = () =>  this.setState({modal: false})

     toggle = () => {
         this.setState({mode: !this.state.mode})
     }

     getMuiTheme = () => createMuiTheme({
        overrides: {
          MUIDataTableHeadCell: {
            fixedHeaderOptions: {
              backgroundColor: `blue !important`,
            }
          },
          MUIDataTableHead: {
            root: {
              backgroundColor: `#1D252D !important` ,
    
            }
          },
          MUIDataTableBodyRow: {
            root: {
              '&:nth-child(odd)': { 
                backgroundColor: '#e3e9ed',
                data: {
                  whiteSpace: 'nowrap'
                }
                
              }
            }
          },
          MuiTableCell: {
            root: {
                padding: '3px 3px 0 0',
                
               
            },
            body: {
                fontSize: '12px',
                textAlign: 'left',
              
            }
        },
    
          MUIDataTableSelectCell: {
            headerCell: {
              backgroundColor: 'white'
            },
            checked: `lightcoral !important`
          },
          MUIDataTablePagination: {
            root: {
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              textAlign: "center"
            },
            caption: {
              fontSize: 12
            }
          }
        }
      })
     
     render(){
        const Terminal = [
            {
              name: "Tran Date",
              options: {
                filter: true,
                customHeadRender: (columnMeta, updateDirection) => (
                  <th
                    key={2}
                    onClick={() => updateDirection(2)}
                    style={{ cursor: "pointer", color: "#172433" }}
                  >
                    {columnMeta.name}
                  </th>
                ),
                setCellHeaderProps: (value) => {
                  return {
                    style: {
                      backgroundColor: "white",
      
                      whiteSpace: "pre",
                      color: "#172433",
                    },
                  };
                },
              },
            },
            {
              name: "Tran Description",
              options: {
                filter: true,
                customHeadRender: (columnMeta, updateDirection) => (
                  <th
                    key={2}
                    onClick={() => updateDirection(2)}
                    style={{ cursor: "pointer", color: "#172433" }}
                  >
                    {columnMeta.name}
                  </th>
                ),
                setCellHeaderProps: (value) => {
                  return {
                    style: {
                      backgroundColor: "white",
      
                      whiteSpace: "pre",
                      color: "#172433",
                    },
                  };
                },
              },
            },
            {
              name: "Tran Reference",
              options: {
                filter: true,
                customHeadRender: (columnMeta, updateDirection) => (
                  <th
                    key={2}
                    onClick={() => updateDirection(2)}
                    style={{ cursor: "pointer", color: "#172433" }}
                  >
                    {columnMeta.name}
                  </th>
                ),
                setCellHeaderProps: (value) => {
                  return {
                    style: {
                      backgroundColor: "white",
      
                      whiteSpace: "pre",
                      color: "#172433",
                    },
                  };
                },
              },
            },
            {
              name: "Amount Credited",
              options: {
                filter: true,
                customHeadRender: (columnMeta, updateDirection) => (
                  <th
                    key={2}
                    onClick={() => updateDirection(2)}
                    style={{ cursor: "pointer", color: "#172433" }}
                  >
                    {columnMeta.name}
                  </th>
                ),
                setCellHeaderProps: (value) => {
                  return {
                    style: {
                      backgroundColor: "white",
      
                      whiteSpace: "pre",
                      color: "#172433",
                    },
                  };
                },
              },
            },
            {
                name: "Amount Debited",
                options: {
                  filter: true,
                  customHeadRender: (columnMeta, updateDirection) => (
                    <th
                      key={2}
                      onClick={() => updateDirection(2)}
                      style={{ cursor: "pointer", color: "#172433" }}
                    >
                      {columnMeta.name}
                    </th>
                  ),
                  setCellHeaderProps: (value) => {
                    return {
                      style: {
                        backgroundColor: "white",
        
                        whiteSpace: "pre",
                        color: "#172433",
                      },
                    };
                  },
                },
              },
              {
                name: "Balance",
                options: {
                  filter: true,
                  customHeadRender: (columnMeta, updateDirection) => (
                    <th
                      key={2}
                      onClick={() => updateDirection(2)}
                      style={{ cursor: "pointer", color: "#172433" }}
                    >
                      {columnMeta.name}
                    </th>
                  ),
                  setCellHeaderProps: (value) => {
                    return {
                      style: {
                        backgroundColor: "white",
        
                        whiteSpace: "pre",
                        color: "#172433",
                      },
                    };
                  },
                },
              },
        ];
        const options = {
            filter: true,
            selectableRows: true,
            filterType: "dropdown",
            responsive: "stacked",
            rowsPerPage: 7,
          };
                      
         return(
             <>
                  
                  <div>
                  {this.state.navbar && 
                 <div className="borderNav pt-2" style={{textDecoration: 'none'}}>
                   <a href="/account_detail" style={{textDecoration: 'none'}}><p className="pr-3 pl-3 text-white">Account Details</p></a>
                     <a href="/view_statement" style={{textDecoration: 'none'}}><p className="pr-3 pl-3 text-warning">View Statement</p></a>
                     <a href="/chequebook_request" style={{textDecoration: 'none'}}><p className="pr-3 text-white">Chequebook Request</p></a>
                     </div>}

                     <CRow className="pt-3">
        <CCol  md="6" className="offset-3">
          <CCard>
            <CCardHeader className="font-weight-bold">
              Search And View Account Statements
            </CCardHeader>
            <CCardBody>
           
              <CRow>
                <CCol xs="12">
                  <CFormGroup>
                    <CLabel htmlFor="name" className="font-weight-bold">Select Record</CLabel>
                    <CSelect custom name="select" id="select" onChange={this.onChange}>
                      <option>All</option>
                      <option>Debit Only</option>
                      <option>Credit Only</option>
                    </CSelect>
                  </CFormGroup>
                </CCol>
              </CRow>
              <CRow>
                <CCol xs="12" className="pb-2 pt-2">
                
                    <RangePicker />
                 

                </CCol>
              </CRow>
              <CButton size="md" className="btn-facebook btn-brand mr-1 mb-1">Search</CButton>

          
            </CCardBody>
          </CCard>
        </CCol>

        <CCol md="12" >
          <CCard >
            <CCardHeader className="font-weight-bold">
              <div className="d-flex justify-content-between align-items-center">
                 
                      <p>CUSTOMER NAME- MICHEAL HARRY</p>
                      <p>ACCOUNT NUMBER- 090123344 </p>
              </div>
            </CCardHeader>
            
          </CCard>
        </CCol>
  
  
      </CRow>
      <CRow>
          <CCol md="12">
          <MuiThemeProvider theme={this.getMuiTheme()} className="ml-3">
                  <MUIDataTable
                    title={"STATEMENT OF ACCOUNT INFORMATION"}
                    data={this.dataSet}
                    columns={Terminal}
                    options={options}
                  />
                </MuiThemeProvider>
          </CCol>
      </CRow>

                   


                 </div>

         
             </>
         )
     }
     dataSet = [
        ["20/06/2020", "NIP FROM CYPRIAN OBINNA EYA/TRF IFO OVAGA PASCHAL IKEM. /000014/221982126401", "FOZEXA2067245RT", "", "NGN100,000.00", "NGN150,000.00"],
        ["20/06/2020", "NIP TRANSFER IFO HILLARY NNAEMEKA OVAGA Interbank REF: 44136659", "FOZEXA20167037W", "NGN50,000.00", "", "NGN100,000.00"],
        ["20/06/2020", "VAT NIP TRANSFER IFO HILLARY NNAEMEKA OVAGA Interbank REF: 44136659", "FOZEXA20167037W", "NGN1.88", "", "NGN99,998.22"],
        ["20/06/2020", "CHARGE NIP TRANSFER IFO HILLARY NNAEMEKA OVAGA Interbank REF: 44136659", "FOZEXA20167037W", "NGN25.00", "", "NGN99,973.22"],
        ["20/06/2020", "STAMP DUTY CHARGE IFO FG", "FOZEXA20167037W", "NGN50.00", "", "NGN99,923.22"]
      ];
 }
 export default ViewStatement