import React from "react";
import { Button, Form, FormGroup, Label, FormText , InputGroup, InputGroupAddon, InputGroupText, Input, CardBody, Card} from "reactstrap";
// import { Form, Input, Button, Checkbox } from 'antd';
import Cookie from 'js-cookie'
import OtpInput from 'react-otp-input';
import {Link} from 'react-router-dom'

import HeaderAuth from '../landing/headerAuth'


class Register extends React.Component {
  state ={
    username: '',
    password: '',
    first: true,
    second: false,
    third:false,
    fourth: false,
    otp:'',
    otp1: ''
  }
  login = () => {
    const login = {
      username: this.state.username,
      password: this.state.password
    }
    Cookie.set('user', JSON.stringify(login))
    console.log(login)
   this.props.history.push('/dashboard')
  }

  onChange =(e) => {
    const {name, value} = e.target;
    this.setState({
      [name]: value
    })
  }

  next1 = () => {
      this.setState({second:true, first:false, third:false, fourth:false})

  }
  prev1 = () => {
    this.setState({second:false, first:true, third:false, fourth:false})

  }
  
  next2 = () => {
    this.setState({second:false, first:false, third:true, fourth:false})

}
prev2 = () => {
  this.setState({second:true, first:false, third:false, fourth:false})

}

handleChange = otp => {
    this.setState({ otp : otp });
    console.log(otp)
}
handleChange2 = otp => {
    this.setState({ otp1 : otp });
    console.log(otp)
}

   
  render() {
    
    return (
      <>
      <HeaderAuth />
        <div className="mt-5 ">
          <div className="row mt-5">
          <div className="col-md-6">
            <Link to="/">
            <div className="mt-5 pt-5 pl-5 ml-5" style={{background:'white'}}>
                        <a href="/"><img src={require('../../img/sign.jpg')} alt="logo" className="w-100"/></a>
                    </div>
            </Link>
            </div>
        
            
            <div className="col-md-6 mt-4">
          
         
             

                         
             
                <div className="mt-2 pt-2">
                  <h2 className="text-center">Welcome to <span className="text-info">Cititrust Financial</span>.</h2>
                  <div className="pt-2">
                    <div className="d-flex justify-content-center">
                    <Button style={{background: '#017DC3', color:'white'}} color="#017DC3" className="mr-2">SIGN UP</Button>
                    <Link to="/login"><Button style={{backgroundColor: 'white'}}>SIGN IN</Button></Link>
                    </div>
                

                  </div>

                  <Form className="col-md-6 offset-3 pt-2">
                      {this.state.first &&
                  <div className="">
      <FormGroup>
        
        <Label for="exampleEmail" className="font-weight-bold">First Name</Label>
        <Input type="email" name="username" id="exampleEmail" onChange={this.onChange}   />
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword" className="font-weight-bold">Middle Name</Label>
        <Input type="password" name="password" id="examplePassword"   onChange={this.onChange}  />
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword" className="font-weight-bold">Last Name</Label>
        <Input type="password" name="password" id="examplePassword"   onChange={this.onChange}  />
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword" className="font-weight-bold">Email Address</Label>
        <Input type="password" name="password" id="examplePassword"   onChange={this.onChange}  />
      </FormGroup>
      <Button style={{background: '#017DC3', color:'white' }} color="#017DC3" size="md" onClick={this.next1} className="btn btn-block">NEXT</Button>
      </div>}

      {this.state.second &&
                  <div className="">
      <FormGroup>
        
        <Label for="exampleEmail" className="font-weight-bold">Date of Birth</Label>
        <Input type="email" name="username" id="exampleEmail" onChange={this.onChange}   />
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword" className="font-weight-bold">Phone Number</Label>
        <Input type="password" name="password" id="examplePassword"   onChange={this.onChange}  />
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword" className="font-weight-bold">Bank Verification Number</Label>
        <Input type="password" name="password" id="examplePassword"   onChange={this.onChange}  />
      </FormGroup>
      <div className="text-center">
      <Button style={{background: '#017DC3', color:'white' }} color="#017DC3" size="md" onClick={this.prev1} className="">Prev</Button>{" "}
      <Button style={{background: '#017DC3', color:'white'}} color="#017DC3" size="md" onClick={this.next2} className="">NEXT</Button>

      </div>
     
      </div>}
     

      {this.state.third &&
      
                  <div className="pt-3 pb-5 text-center">
                       <FormGroup>
          <Label className="font-weight-bold">Create Your PIN</Label>
      </FormGroup>
             <OtpInput
          value={this.state.otp}
          onChange={this.handleChange}

          numInputs={4}
          inputStyle={{textAlign:'center', width:'6rem', height:'2rem'}}
          separator={<span>-</span>}
        />

<FormGroup>
          <Label className="font-weight-bold">Confirm Your PIN</Label>
      </FormGroup>
               <OtpInput

          numInputs={4}
          value={this.state.otp1}
          onChange={this.handleChange2}

          inputStyle={{textAlign:'center', width:'6rem', height:'2rem'}}
          separator={<span>-</span>}
        />
        <br />
      <div className="text-center">
      <Button style={{background: '#017DC3', color:'white' }} color="#017DC3" size="md" onClick={this.prev2} className="">Prev</Button>{" "}
      <Button style={{background: '#017DC3', color:'white' }} color="#017DC3" size="md" onClick={this.next2} className="">NEXT</Button>

      </div>

     
      </div>}
      <p className="text-center pt-3">Already have an account?  <a href="/login">Sign In</a></p>


      </Form>
      
       
                  

                    
                  
                </div>
              
        
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default Register;
