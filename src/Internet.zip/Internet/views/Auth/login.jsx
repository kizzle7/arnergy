import React from "react";
import { Button, Form, FormGroup, Label, FormText , InputGroup, InputGroupAddon, InputGroupText, Input,Card, CardBody} from "reactstrap";
// import { Form, Input, Button, Checkbox } from 'antd';
import Cookie from 'js-cookie'
import {Link } from 'react-router-dom'
import HeaderAuth from '../landing/headerAuth'
import Footer from '../landing/footer'
import { FormProvider } from "antd/lib/form/context";

class Login extends React.Component {
  state ={
    username: '',
    password: ''
  }
  login = () => {
    const login = {
      username: this.state.username,
      password: this.state.password
    }
    Cookie.set('user', login.username)
    console.log(login)
    window.location.replace('/dashboard');
  }

  onChange =(e) => {
    const {name, value} = e.target;
    this.setState({
      [name]: value
    })
  }

   
  render() {
    
    return (
      <>
      <HeaderAuth />
    

        <div className="mt-5">
          <div className="row mt-5">
            <div className="col-md-6">
            <Link to="/">
            <div className="mt-5 pt-5 pl-5 ml-5" style={{background:'white'}}>
                        <a href="/"><img src={require('../../img/regImage.jpg')} alt="logo" className="w-100"/></a>
                    </div>
            </Link>
            </div>
            <div className="col-md-6">
             <br />
           


             
                <div className="mt-5">
                  <h2 className="text-center">Welcome to <span className="text-info">Cititrust Financials</span>.</h2>
 <div className="pt-3">
                    <div className="d-flex justify-content-center">
                    <Link to="/register"><Button style={{background:'white'}}>SIGN UP</Button></Link>     
                                   <Button style={{background: '#017DC3', color: 'white'}} color="#017DC3" className="ml-2">SIGN IN</Button>

                    </div>
                

                  </div>
                  <Form className="col-md-6 offset-3 pt-4">
                  <div className="">
      <FormGroup>
        
        <Label for="exampleEmail" className="font-weight-bold">Username</Label>
        <Input type="email" name="username" id="exampleEmail" onChange={this.onChange} />
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword" className="font-weight-bold">Password</Label>
        <Input type="password" name="password" id="examplePassword"  onChange={this.onChange} />
      </FormGroup>
      <Button style={{background: '#017DC3', color: 'white'}} color="#017DC3" size="md" onClick={this.login} className="btn btn-block">Submit</Button>
      </div>
      <p className="text-center pt-3">Dont have an account?  <a href="/register">Sign Up</a></p>
      </Form>
      
       
                  

                    
                  
                </div>
             
        
            </div>
          </div>
        </div>
       
 
      </>
    );
  }
}

export default Login;
