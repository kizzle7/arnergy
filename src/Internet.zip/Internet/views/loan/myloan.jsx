import React from 'react';
import { CRow, CCol ,CCard, CCardHeader, CCardBody} from '@coreui/react';
class MyLoan extends React.Component{
    render(){
        return(
            <>

            {/* <div className="container">
                <div className="borderNav pt-2">
                    <a href="/my_loans" style={{textDecoration: 'none'}}><p className="pl-5 text-warning">My Loans</p></a>
                    <a href="/loan_application" style={{textDecoration: 'none'}}><p className="text-white" style={{textDecoration: 'none'}}> Loan Application</p></a>
                    <a href="/loan_status" style={{textDecoration: 'none'}}><p className="pr-5 text-white" style={{textDecoration: 'none'}}>Loan Status</p></a>
                </div>

            </div> */}
            <div className="pt-5 container"> 
                <CRow>
                <CCol md="12" >
      <CCard className="mb-5" style={{background:'white'}}>
            <CCardHeader style={{background:'white', color:'black'}}>
              <div className="d-flex justify-content-between">
              <small className="font-weight-bold">My Loans </small>
              <small  className="font-weight-bold">JUNE 22 2020</small>
              </div>
             
            </CCardHeader>
            <CCardBody>
    
             <div className="row">
              <div className="col-md-2">
                  <p className="font-weight-bold">Request Date</p>
              </div>
              <div className="col-md-3">
                  <p className="font-weight-bold">Purpose of loan</p>
              </div>
              <div className="col-md-3">
                  <p className="font-weight-bold" >Loan Amount</p>
              </div>
              <div className="col-md-2">
                  <p className="font-weight-bold">Status</p>
              </div>
              <div className="col-md-2">
                  <p className="font-weight-bold">Action</p>
              </div>
          </div>
          <div className="row">
              <div className="col-md-2">
                  <p>16/06/2020</p>
              </div>
              <div className="col-md-3">
                  <p>Medical</p>
              </div>
              <div className="col-md-3">
                  <p>300,000</p>
              </div>
              <div className="col-md-2">
                  <p className="text-warning">Pending</p>
              </div>
              <div className="col-md-2">
                 <button className="default">View Detail</button> 
              </div>
          </div>
          <div className="row">
              <div className="col-md-2">
                  <p>05/05/2020</p>
              </div>
              <div className="col-md-3">
                  <p>Medical</p>
              </div>
              <div className="col-md-3">
                  <p>450,000</p>
              </div>
              <div className="col-md-2">
                  <p className="text-danger">Rejected</p>
              </div>
              <div className="col-md-2">
                 <button className="default">View Detail</button> 
              </div>
          </div>
          <div className="row">
              <div className="col-md-2">
                  <p>17/05/2019</p>
              </div>
              <div className="col-md-3">
                  <p>Rent</p>
              </div>
              <div className="col-md-3">
                  <p>350,000</p>
              </div>
              <div className="col-md-2">
                  <p className="text-success">Approved</p>
              </div>
              <div className="col-md-2">
                 <button className="default">View Detail</button> 
              </div>
          </div>

          <div className="row">
              <div className="col-md-2">
                  <p>20/04/2019</p>
              </div>
              <div className="col-md-3">
                  <p>Education</p>
              </div>
              <div className="col-md-3">
                  <p>700,000</p>
              </div>
              <div className="col-md-2">
                  <p className="text-danger">Rejected</p>
              </div>
              <div className="col-md-2">
                 <button className="default">View Detail</button> 
              </div>
          </div>
        
         
               
               

            </CCardBody>
          </CCard>
        
         
        </CCol>
                </CRow>
            </div>
            </>
        )
    }
}
export default MyLoan;