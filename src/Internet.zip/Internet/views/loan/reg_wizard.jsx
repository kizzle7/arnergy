import React, { Component } from 'react';

class Custom extends Component {
    render() {
        return (
            <div className="checkout">
                <div className={this.props.step1 ? 'active': ''}>Personal Info</div>
                <div className={this.props.step2 ? 'active': ''}>Education And Employment</div>
                <div className={this.props.step3 ? 'active': ''}>Address </div>
                <div className={this.props.step4 ? 'active': ''}>Other Services</div>


            </div>
        );
    }
}

export default Custom;