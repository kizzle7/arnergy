import React from 'react';
import {
    CRow,
    CCol,
    CCard,
    CCardBody,
    CCardHeader,
    CDropdown,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CNav,
    CInputCheckbox,
    CNavItem,
    CFormGroup,
    CForm,
    CLabel,
    CInput,
    CFormText,
    CSelect,
    CTextarea,
    CNavLink,
    CCardFooter,
    CButton
  } from '@coreui/react'
  import Checkbox from "@material-ui/core/Checkbox";
  import { InputGroup, InputGroupAddon, InputGroupText, Input } from 'reactstrap';

import FormControlLabel from "@material-ui/core/FormControlLabel";
import {Modal} from 'antd'
class PaymentTransfer extends React.Component{
  state = {
    first: true,
    second:false,
    third:false,
    fourth:false,
    updateCheck: false,
    firstModal:false,
    secondModal:false,
    updateCheck2:false,
    country: ''
  }

  checkChange = (e) => {
    const {name, checked} = e.target;
    if(checked){
      this.setState({updateCheck: true, updateCheck2:false})
    }
  }

  checkChange2 = (e) => {
    const {name, checked} = e.target;
    if(checked){
      this.setState({updateCheck2: true, updateCheck:false})
    }
  }

  sendOther = () => {
    this.setState({firstModal:false})
  }

  first = () => {
    this.setState({first: true, second:false, third:false, fourth:false})
  }

  second = () => {
    this.setState({first:false, second:true, third:false, fourth:false})
  }

  third =() => {
    this.setState({first:false, second:false, third:true, fourth:false})
  }

  fourth =() => {
    this.setState({first:false, second:false, third:false, fourth:true})
  }

  sendOwn = () => {
    this.setState({firstModal: true})
  }

  onChange =(e) => {
    const {name, value} = e.target;
    this.setState({[name]: value})
  }
    render(){

        return(
            <>
            <div className="col-md-8 offset-2">
                <div className="transferNav">
                    <p className="itemTransferActive" className={this.state.first ? 'itemTransferActive': 'itemTransfer'}  onClick={this.first}>Own Account</p>
                    <p className={this.state.second ? 'itemTransferActive': 'itemTransfer'} onClick={this.second}>Other FirstOption Account</p>
                    <p className={this.state.third ? 'itemTransferActive': 'itemTransfer'} onClick={this.third}>Other Banks</p>
                    <p className={this.state.fourth ? 'itemTransferActive': 'itemTransfer'} onClick={this.fourth}>Cititrust- Africa</p>

                </div>


                <CRow className="pt-3">
         {this.state.first &&         
        <CCol md="12">
          <CCard>
           
            <CCardBody>
              <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
               
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Transfer From</CLabel>
                  </CCol>
                  <CCol  md="6">
                  <CSelect custom name="select" id="select">
                      <option value="0">Select Account</option>
                      <option value="1">02236282733</option>
                      <option value="2">O115272863</option>
                    </CSelect>
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Beneficiary Account Number</CLabel>
                  </CCol>
                  
                  <CCol  md="6">
                  <CSelect custom name="select" id="select">
                      <option value="0">Select Account</option>
                      <option value="1">02236282733</option>
                      <option value="2">O115272863</option>
                    </CSelect>
                  </CCol>
                </CFormGroup>
              
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Amount</CLabel>
                  </CCol>
                 
                  <CCol  md="6">
                  <InputGroup>
        <InputGroupAddon addonType="prepend">
          <InputGroupText>NGN</InputGroupText>
        </InputGroupAddon>
        <Input  />
      </InputGroup>
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Purpose</CLabel>
                  </CCol>
                  <CCol  md="6">
                    <CInput id="text-input" name="text-input" />
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Beneficiary Email</CLabel>
                  </CCol>
                  <CCol  md="6">
                    <CInput id="text-input" name="text-input"  />
                  </CCol>
                </CFormGroup>
                </CForm>
                </CCardBody>
                <CCardFooter>
              <CButton type="submit" size="md" color="dark" onClick={this.sendOwn}> Send</CButton>
            </CCardFooter>
                </CCard>
                </CCol>}

                {this.state.second &&

                <CCol md="12">
          <CCard>
           
            <CCardBody>
              <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
               
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Transfer From</CLabel>
                  </CCol>
                  <CCol  md="6">
                  
                  <CSelect custom name="select" id="select">
                      <option value="0">Select Account</option>
                      <option value="1">02236282733</option>
                      <option value="2">O115272863</option>
                    </CSelect>
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input" className="pt-2">Beneficiary Account Number</CLabel>
                  </CCol>
                  <FormControlLabel className="pl-2"
                      control={
                        <Checkbox
                          checked={this.state.updateCheck}
                          className="ml-1"
                          onChange={this.checkChange}
                          name="updateCheck"
                          color="primary"
                        />
                      }
                      label="New "
                    />
                       <FormControlLabel
                      control={
                        <Checkbox
                          checked={this.state.updateCheck2}
                          onChange={this.checkChange2}
                          name="updateCheck2"
                          color="primary"
                        />
                      }
                      label="Existing"
                    />
                  {this.state.updateCheck2 &&
                  <CCol  md="6" className="pt-3 pb-2 offset-4">
                  <CSelect custom name="select" id="select">
                      <option value="0">Select Account</option>
                      <option value="1">02236282733</option>
                      <option value="2">O115272863</option>
                    </CSelect>
                  </CCol>}
                  {this.state.updateCheck &&
                    <CCol  md="6" className="offset-4">
                      <CLabel htmlFor="text-input">Account Number</CLabel>
                    <CInput id="text-input" name="text-input" />
                  </CCol>
                  }

                </CFormGroup>
              
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Amount</CLabel>
                  </CCol>
                 
                  <CCol  md="6">
                  <InputGroup>
        <InputGroupAddon addonType="prepend">
          <InputGroupText>NGN</InputGroupText>
        </InputGroupAddon>
        <Input  />
      </InputGroup>                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Purpose</CLabel>
                  </CCol>
                  <CCol  md="6">
                    <CInput id="text-input" name="text-input" />
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Beneficiary Email</CLabel>
                  </CCol>
                  <CCol  md="6">
                    <CInput id="text-input" name="text-input"  />
                  </CCol>
                </CFormGroup>
                </CForm>
                </CCardBody>
                <CCardFooter>
              <CButton type="submit" size="md" color="dark" onClick={this.sendOwn}> Send</CButton>
            </CCardFooter>
                </CCard>
                </CCol>}

                {this.state.third &&

<CCol md="12">
<CCard>
 
  <CCardBody>
    <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
     
      <CFormGroup row>
        <CCol md="4">
          <CLabel htmlFor="text-input">Transfer From</CLabel>
        </CCol>
        <CCol  md="6">
        
        <CSelect custom name="select" id="select">
            <option value="0">Select Account</option>
            <option value="1">02236282733</option>
            <option value="2">O115272863</option>
          </CSelect>
        </CCol>
      </CFormGroup>
      <CFormGroup row>
        <CCol md="4">
          <CLabel htmlFor="text-input" className="pt-2">Beneficiary Account Number</CLabel>
        </CCol>
        <FormControlLabel className="pl-2"
            control={
              <Checkbox
                checked={this.state.updateCheck}
                className="ml-1"
                onChange={this.checkChange}
                name="updateCheck"
                color="primary"
              />
            }
            label="New "
          />
             <FormControlLabel
            control={
              <Checkbox
                checked={this.state.updateCheck2}
                onChange={this.checkChange2}
                name="updateCheck2"
                color="primary"
              />
            }
            label="Existing"
          />
        {this.state.updateCheck2 &&
        <CCol  md="6" className="pt-3 pb-2 offset-4">
        <CSelect custom name="select" id="select">
            <option value="0">Select Account</option>
            <option value="1">02236282733</option>
            <option value="2">O115272863</option>
          </CSelect>
        </CCol>}
        {this.state.updateCheck &&
          <CCol  md="6" className="offset-4">
                                  <CLabel htmlFor="text-input">Account Number</CLabel>

          <CInput id="text-input" name="text-input" />
        </CCol>
        }

      </CFormGroup>
    
      <CFormGroup row>
        <CCol md="4">
          <CLabel htmlFor="text-input">Amount</CLabel>
        </CCol>
      
        <CCol  md="6">
        <InputGroup>
        <InputGroupAddon addonType="prepend">
          <InputGroupText>NGN</InputGroupText>
        </InputGroupAddon>
        <Input  />
      </InputGroup>        </CCol>
      </CFormGroup>
      <CFormGroup row>
        <CCol md="4">
          <CLabel htmlFor="text-input">Bank Name</CLabel>
        </CCol>
       
        <CCol  md="6">
        <CSelect custom name="select" id="select">
            <option value="0">Select Bank</option>
            <option value="1">GT Bank</option>
            <option value="2">Zenith Bank</option>
            <option value="1">First Bank</option>
            <option value="2">Polaris Bank</option>
            <option value="1">Access Bank</option>
            <option value="2">Unity Bank</option>
          </CSelect>
        </CCol>
      </CFormGroup>
      <CFormGroup row>
        <CCol md="4">
          <CLabel htmlFor="text-input">Purpose</CLabel>
        </CCol>
        <CCol  md="6">
          <CInput id="text-input" name="text-input" />
        </CCol>
      </CFormGroup>
      <CFormGroup row>
        <CCol md="4">
          <CLabel htmlFor="text-input">Beneficiary Email</CLabel>
        </CCol>
        <CCol  md="6">
          <CInput id="text-input" name="text-input"  />
        </CCol>
      </CFormGroup>
      </CForm>
      </CCardBody>
      <CCardFooter>
    <CButton type="submit" size="md" color="dark" onClick={this.sendOwn}> Send</CButton>
  </CCardFooter>
      </CCard>
      </CCol>}

                {this.state.fourth &&

                <CCol md="12">
          <CCard>
           
            <CCardBody>
              <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
               
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Transfer From</CLabel>
                  </CCol>
                  <CCol  md="6">
                  <CSelect custom name="select" id="select">
                      <option value="0">Select Account</option>
                      <option value="1">02236282733</option>
                      <option value="2">O115272863</option>
                    </CSelect>
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Destination Category</CLabel>
                  </CCol>
                  <CCol  md="6">
                  <CSelect custom name="country" id="select" onChange={this.onChange}>
                      <option value="NGN">Select Account</option>
                      <option value="NGN">Nigeria</option>
                      <option value="RAND">South Africa</option>
                      <option value="CEDIS">Liberia</option>
                    </CSelect>
                  </CCol>
                </CFormGroup>
                <p className="font-weight-bold">Transaction Details</p>
                <CFormGroup row>
        <CCol md="4">
          <CLabel htmlFor="text-input" className="pt-2">Beneficiary Account Number</CLabel>
        </CCol>
        <FormControlLabel className="pl-2"
            control={
              <Checkbox
                checked={this.state.updateCheck}
                className="ml-1"
                onChange={this.checkChange}
                name="updateCheck"
                color="primary"
              />
            }
            label="New "
          />
             <FormControlLabel
            control={
              <Checkbox
                checked={this.state.updateCheck2}
                onChange={this.checkChange2}
                name="updateCheck2"
                color="primary"
              />
            }
            label="Existing"
          />
        {this.state.updateCheck2 &&
        <CCol  md="6" className="pt-3 pb-2 offset-4">
        <CSelect custom name="select" id="select">
            <option value="0">Select Account</option>
            <option value="1">02236282733</option>
            <option value="2">O115272863</option>
          </CSelect>
        </CCol>}
        {this.state.updateCheck &&
          <CCol  md="6" className="offset-4">
                                  <CLabel htmlFor="text-input">Account Number</CLabel>

          <CInput id="text-input" name="text-input" />
        </CCol>
        }

      </CFormGroup>
          
              
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Amount</CLabel>
                  </CCol>
                 
                  <CCol  md="6">
                  <InputGroup>
        <InputGroupAddon addonType="prepend">
          <InputGroupText>NGN</InputGroupText>
        </InputGroupAddon>
        <Input  />
      </InputGroup>                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Purpose</CLabel>
                  </CCol>
                  <CCol  md="6">
                    <CInput id="text-input" name="text-input" />
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Beneficiary Email</CLabel>
                  </CCol>
                  <CCol  md="6">
                    <CInput id="text-input" name="text-input"  />
                  </CCol>
                </CFormGroup>
                </CForm>
                </CCardBody>
                <CCardFooter>
              <CButton type="submit" size="md" color="dark" onClick={this.sendOwn}> Send</CButton>
            </CCardFooter>
                </CCard>
                </CCol>}
                </CRow>

            </div>

            <Modal
          title="Security Question and PIN Confirmation"
          visible={this.state.firstModal}
          // onOk={this.singleTerminal}
          onCancel={this.sendOther}
          footer={null}
          okText="Add Terminal"
          cancelText="Clear"
          maskClosable={false}
          centered={true}
          
        >
          <p className="font-weight-bold text-center">Security Question</p>
<CFormGroup row>
                  <CCol md="7">
                    <CLabel htmlFor="text-input">What is your Mother's Maiden Name?</CLabel>
                  </CCol>
                  <CCol  md="5">
                  <CInput id="text-input" name="text-input"  />

                  </CCol>
                </CFormGroup>    
                <hr />
                      <p className="font-weight-bold text-center">PIN</p>
          <CFormGroup row>
                  <CCol md="7">
                    <CLabel htmlFor="text-input">Input PIN</CLabel>
                  </CCol>
                  <CCol  md="5">
                  <CInput id="text-input" name="text-input"  />

                  </CCol>
                </CFormGroup>
                <div className="text-center">
                <CButton type="submit" size="lg" color="success" onClick={this.sendOwn}> Submit</CButton>
                </div>


          
          </Modal>
            </>
        )
    }
}
export default PaymentTransfer