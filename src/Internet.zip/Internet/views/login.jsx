import React from "react";
import { Button, Form, FormGroup, Label, FormText , InputGroup, InputGroupAddon, InputGroupText, Input} from "reactstrap";
// import { Form, Input, Button, Checkbox } from 'antd';

class Login extends React.Component {
  login = () => {
    this.props.history.push('/dashboard')
  }

   
  render() {
    
    return (
      <>
        <div>
          <div className="row">
            <div className="col-md-6">
              <img src={require("../img/citpic.jpg")} className="w-100" />
            </div>
            <div className="col-md-6">
              <div className="container mb-0 pb-0 ">
               
                <div className="text-center">
                  <p className="font-weight-bold text-info">LOGIN</p>
                  <p className=" text-mute pt-3">Please choose how you would like to Log in today</p>
                 
                  <div className="col-md-6 offset-3 pt-2">
                 
                    <Form className="">
                    <FormGroup>
                        <Input type="select" name="select" id="exampleSelect">
                        <option>PIN and Token</option>
                          <option>Password</option>
                          
                        </Input>
                      </FormGroup>
                      <InputGroup>
        <InputGroupAddon addonType="prepend">
          <InputGroupText><i className="fa fa-user"></i></InputGroupText>
        </InputGroupAddon>
        <Input placeholder="ACCOUNT NUMBER" />
      </InputGroup>
      
      <InputGroup>
        <InputGroupAddon addonType="prepend">
          <InputGroupText><i className="fa fa-lock"></i></InputGroupText>
        </InputGroupAddon>
        <Input placeholder="PIN AND TOKEN" />
      </InputGroup>
      <Button color="info" size="md" onClick ={this.login} className="btn btn-block mt-3 font-weight-bold">LOGIN</Button>
                     
                    
                    </Form>
                  

                    
                  </div>
                </div>
              </div>
              <div className="text-right mt-4 pt-4">
                        <Button color="dark" size="md">Other Services</Button>
                    </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default Login;
