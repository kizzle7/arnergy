import React from 'react';
import {
    CRow,
    CCol,
    CCard,
    CCardBody,
    CCardHeader,
    CDropdown,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CNav,
    CNavItem,
    CFormGroup,
    CForm,
    CLabel,
    CInput,
    CFormText,
    CSelect,
    CTextarea,
    CNavLink,
    CCardFooter,
    CInputCheckbox,
    CButton
  } from '@coreui/react'
  import {Card} from 'reactstrap'

  import WidgetsRemittance from '../widgets/WidgetsRemittance.js'
class Remittance extends React.Component{
    render(){
        return(
            <>
        <CRow>
              <CCol sm="12" md="12">
                <CCard>
                  <CCardHeader>
                  <small className="font-weight-bold">Remittance Category</small>
                  </CCardHeader>
                  <CCardBody>
                  <WidgetsRemittance />
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>

            </>
        )
    }
}
export default Remittance