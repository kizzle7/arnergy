import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import {
  CCreateElement,
  CSidebar,
  CSidebarBrand,
  CSidebarNav,
  CSidebarNavDivider,
  CSidebarNavTitle,
  CSidebarMinimizer,
  CSidebarNavDropdown,
  CSidebarNavItem,
} from '@coreui/react'

import CIcon from '@coreui/icons-react'

// sidebar nav config
import navigation from './_nav'

const TheSidebar = () => {
  const dispatch = useDispatch()
  const show = useSelector(state => state.sidebarShow)

  return (
    <CSidebar
      show={show}
      onShowChange={(val) => dispatch({type: 'set', sidebarShow: val })}
    >
      <CSidebarBrand className="d-md-down-none" to="/" className="pt-2" style={{textDecoration: 'none'}}>
        
        <div className="text-center c-sidebar-brand-full" style={{fontSize: '12px'}}>
          <i className="text-center fa fa-user-circle fa-2x pb-3"></i>
          <p className="text-left pt-0" style={{fontSize: '12px', textDecoration:'none'}}>Username <i className="fa fa-share"></i> Misheal Harry</p>
          <p className="text-left" style={{fontSize: '12px'}}>Account No <i className="fa fa-share"></i> 090123344</p>
          <p className="text-left" style={{fontSize: '12px'}}>Balance <i className="fa fa-share"></i> NGN15000</p>

        </div>
        <div className="text-center c-sidebar-brand-minimized">
          <i className="text-center fa fa-user-circle fa-2x pb-3"></i>
        
        </div>

        {/* <CIcon
          className="c-sidebar-brand-full"
          name="logo-negative"
          height={35}
        />
        <CIcon
          className="c-sidebar-brand-minimized"
          name="sygnet"
          height={35}
        /> */}
      </CSidebarBrand>
      <CSidebarNav className="pt-4 text-white">

        <CCreateElement
          items={navigation}
          className="text-white"
          components={{
            CSidebarNavDivider,
            CSidebarNavDropdown,
            CSidebarNavItem,
            CSidebarNavTitle
          }}
        />
      </CSidebarNav>
      <CSidebarMinimizer className="c-d-md-down-none" />
    </CSidebar>
  )
}

export default React.memo(TheSidebar)
