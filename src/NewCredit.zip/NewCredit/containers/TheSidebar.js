import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import {
  CCreateElement,
  CSidebar,
  CSidebarBrand,
  CSidebarNav,
  CSidebarNavDivider,
  CSidebarNavTitle,
  CSidebarMinimizer,
  CSidebarNavDropdown,
  CSidebarNavItem,
} from '@coreui/react'

import CIcon from '@coreui/icons-react'

// sidebar nav config
import navigation from './_nav'

const TheSidebar = (props) => {
  const dispatch = useDispatch()
  const show = useSelector(state => state.sidebarShow)
 const wallet = sessionStorage.getItem('amt')

  return (
    <CSidebar
      show={show}
      onShowChange={(val) => dispatch({type: 'set', sidebarShow: val })}
    >
      <CSidebarBrand className="d-md-down-none" to="/" className="pt-2" style={{textDecoration: 'none'}}>
        
      <div className="text-center c-sidebar-brand-full" style={{fontSize: '12px'}}>
        <div className="text-center">
        <img src={require('../img/cititrust_financial.png')} width="43%" className="pt-1" />

        </div>
          <p className="text-center pt-0 pl-4 text-dark" style={{fontSize: '12px', textDecoration:'none'}}>Username : Paschal Ovaga Ikem</p>
          <p className="text-center pl-4 text-dark" style={{fontSize: '12px'}}>Wallet Balance: 0.00 </p>
          <div className="d-flex justify-content-center align-items-center" >
            <img src={require('../img/nija.png')} width="18%" className="pb-3"  />

            </div>


        </div>
        <div className="text-center c-sidebar-brand-minimized">
          <i className="text-center fa fa-user-circle fa-2x pb-3"></i>
        
        </div>

        {/* <CIcon
          className="c-sidebar-brand-full"
          name="logo-negative"
          height={35}
        />
        <CIcon
          className="c-sidebar-brand-minimized"
          name="sygnet"
          height={35}
        /> */}
      </CSidebarBrand>
      <CSidebarNav className="pt-3 text-white">

        <CCreateElement
          items={navigation}
          className="text-white"
          components={{
            CSidebarNavDivider,
            CSidebarNavDropdown,
            CSidebarNavItem,
            CSidebarNavTitle
          }}
        />
      </CSidebarNav>
     
    </CSidebar>
  )
}

export default React.memo(TheSidebar)
