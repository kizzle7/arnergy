import React from 'react'
import {
  CBadge,
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
  CImg
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {Redirect} from 'react-router-dom'
import Cookie from 'js-cookie'

class TheHeaderDropdown extends React.Component{
  state = {
    log: false
  }
  logout = () => {
    Cookie.remove('user')
    Cookie.remove('loan')

    this.setState({
      log:true
    })
  }
  render(){
    if(this.state.log){
      return(
        <Redirect to ="/" />
      )
    }
    return (
      <CDropdown
        inNav
        className="c-header-nav-items mx-2"
        direction="down"
      >
        <CDropdownToggle className="c-header-nav-link" caret={false}>
          <div className="c-avatar">
          <i className="fa fa-user-circle "></i>
          </div>
        </CDropdownToggle>
        <CDropdownMenu className="pt-0" placement="bottom-end">
          <CDropdownItem
            header
            tag="div"
            color="dark"
            className="text-center"
            style={{fontSize: '16px'}}
          >
            <strong>Account</strong>
          </CDropdownItem>
        
          <CDropdownItem
            header
            tag="div"
            color="light"
            className="text-center"
            style={{fontSize: '13px'}}
          >
            <strong>Settings</strong>
          </CDropdownItem>
          <CDropdownItem             style={{fontSize: '13px'}}
>
            <CIcon name="cil-user" className="mfe-2" />Profile
          </CDropdownItem>
          <CDropdownItem             style={{fontSize: '13px'}}
>
            <CIcon name="cil-settings" className="mfe-2" /> 
            Settings
          </CDropdownItem>
          <CDropdownItem             style={{fontSize: '13px'}}
>
            <CIcon name="cil-credit-card" className="mfe-2" /> 
            Payments
            <CBadge color="secondary" className="mfs-auto">42</CBadge>
          </CDropdownItem>
           
          <CDropdownItem divider />
          <CDropdownItem onClick={this.logout}             style={{fontSize: '13px'}}
>
            <CIcon name="cil-lock-locked" className="mfe-2" /> 
            Log Out
          </CDropdownItem>
        </CDropdownMenu>
      </CDropdown>
    )

  }
 
}

export default TheHeaderDropdown
