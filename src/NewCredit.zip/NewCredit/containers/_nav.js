import { CSidebar, CSidebarNavItem, CSidebarNavDropdown } from "@coreui/react";

export default [
 

  
  {
      _tag: CSidebarNavItem,
      name: 'Home',
      icon: 'cil-home',
      to: '/dashboard'
  },
  {
    _tag: CSidebarNavItem,
    name: 'Loans',
    icon: 'cil-notes',
    to: '/my_loans'
},
{
  _tag: CSidebarNavItem,
  name: 'Wallet',
  icon: 'cil-notes',
  to: '/wallet_detail'
},
  {
    _tag: CSidebarNavItem,
    name: 'Send Money',
    icon: 'cil-inbox',
    to: '/send_money_nigeria'
},
{
  _tag: CSidebarNavItem,
  name: 'Airtime Purchase',
  to: '/airtime_purchase',
  icon: 'cil-phone'

},
{
  _tag: CSidebarNavItem,
  name: 'Bill Payment',
  to: '/bill_payment',
  icon: 'cil-credit-card'

},
{
  _tag: CSidebarNavItem,
  name: 'GO Card',
  route: '/base',
  icon: 'cil-credit-card'

},
{
  _tag: CSidebarNavItem,
  name: 'Other Services',
  route: '/base',
  icon: 'cil-settings'

},
{
  _tag: CSidebarNavItem,
  name: 'Log Out',
  route: '/',
  to: '/',
  icon: 'cil-lock-locked',

}

]

