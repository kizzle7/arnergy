import React, { lazy } from 'react'
import Cookie from 'js-cookie'
import {
  CBadge,
  CButton,
  CButtonGroup,
  CCard,
  CCardFooter,
  CCol,
  CProgress,
  CRow,
  CCallout,
  CCardBody,
  CCardHeader,
  CListGroup,
  CListGroupItem,
  CTabContent,
  CSelect,
  CTabPane,
  CFormGroup,
  CForm,
  CLabel,
  CInput,
  CFormText
} from '@coreui/react'
import { Badge } from 'reactstrap';
import {Modal} from 'antd'
import { InputGroup, InputGroupAddon, InputGroupText, Input, Label, FormFeedback, FormGroup } from 'reactstrap';
import CIcon from '@coreui/icons-react'
import '../../assets/font-awesome-4.7.0/css/font-awesome.min.css'
import Loader from 'react-loader-spinner'
import MainChartExample from '../charts/MainChartExample.js'

const WidgetsDropdown = lazy(() => import('../widgets/WidgetsDropdown.js'))
const WidgetsBrand = lazy(() => import('../widgets/WidgetsBrand.js'))

class Dashboard extends React.Component{
  state = {
    select:  false,
    calculator:false,
    load: false,
    show:false
  }

  loanCalculator =() => {
    this.setState({calculator: true})
  }

  calculatorclose =() => {
    this.setState({calculator:false})
  }

  fundwallet = () => {
    this.props.history.push('/fund_your_wallet')
  }

  cal = () => {
    this.setState({load: true})
    setTimeout(() => {
      this.setState({load: false, show: true})
    },3000)
  }

  onChange = (e) => {
    if(e.target.value === "Account-01234673333"){
      this.setState({select: true})
    }
    else{
      this.setState({select: false})
    }
  }
  loan = () =>{
    this.props.history.push('/loan_application')
  }
  render(){
    console.log(this.props)
    const wallet = sessionStorage.getItem('amt')

  return (
    <>
   
     
     
      
      <CRow>
      <CCol md="6">
      <CCard className="mb-5 pb-2" style={{background:'white'}}>
            <CCardHeader style={{background:'white', color:'black'}}>
              <div className="d-flex justify-content-between">
              <small className="font-weight-bold">My Loan</small>
              </div>
             
            </CCardHeader>
            <CCardBody>
             <div className="d-flex justify-content-center align-items-center text-black">
               <big>Get loan in minutes</big>

             </div>
             <div className="pt-3 d-flex justify-content-center align-items-center text-black">
             <CButton size="lg" onClick={this.loan} style={{background:'#017DC3', color:'white'}} >{Cookie.get('loan') !== undefined ? "Continue Loan Application" : " Start Loan Application"}</CButton>
             </div>
             <div className="text-center pb-2">
             <CButton size="sm" onClick={this.loanCalculator} className="mt-4"  color="#017DC3" style={{background:'#017DC3', color: 'white'}}>Loan Calculator</CButton>
            </div>
          
            </CCardBody>
          </CCard>
         
        </CCol>
        
        <CCol md="6">
      <CCard className="mb-5" style={{background:'white'}}>
            <CCardHeader style={{background:'white', color:'black'}}>
              <div className="d-flex justify-content-between">
              <small className="font-weight-bold">My Wallet </small>
              <small  className="font-weight-bold">JUNE 22 2020</small>
              </div>
             
            </CCardHeader>
            <CCardBody>
             <div className="d-flex justify-content-center align-items-center text-black">
               <small>Wallet Balance</small>

             </div>
             <div className="ml-5 d-flex justify-content-center align-items-center text-white">
               <img src={require('../../img/naira.svg')}  width="5%"  className="text-center"/>
               <p className="font-weight-bold text-center h4 pt-2" style={{color:'black'}}>0.00</p>
               <p className="text-white pt-5">66r6567</p>
            
             </div>
            
             <div className="text-center font-weight-bold pb-4">
             <CButton size="sm" onClick={this.fundwallet} className="mt-2"  style={{background:'#017DC3', color:'white'}} >Fund Wallet</CButton>

             </div>
         

            </CCardBody>
          </CCard>
         
        </CCol>
        
        <CCol sm="12" md="12">
        <CCard>
          <CCardHeader>
          <small className="font-weight-bold">Quick Payments</small>
          </CCardHeader>
          <CCardBody>
          <WidgetsDropdown />
          </CCardBody>
        </CCard>
      </CCol>

        <CCol md="12">
        <CCard  className="pb-0">
            <CCardHeader>
            <small className="font-weight-bold ">RECENT ACTIVITY</small>
             
            </CCardHeader>
            <CCardBody>
            <p className="text-center text-black">No recent activity</p>
             
            </CCardBody>
          </CCard>
        </CCol>
        </CRow>

        <Modal
            title={"Loan Calculator"}
            visible={this.state.calculator}
            onCancel={this.calculatorclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
            centered={true}
            style={{marginTop: '7rem'}}
          >
            <div>
             <p className="font-weight-bold text-center">Calculate A Loan Amount</p>
             
                <CFormGroup row>
                  <CCol md="3">
                    <CLabel htmlFor="text-input">Loan Amount</CLabel>
                  </CCol>
                  <CCol xs="12" md="9">
                    <CInput id="text-input" name="text-input" />
                    <CFormText>This represents your intended loan amount</CFormText>
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="3">
                    <CLabel htmlFor="email-input">Loan Tenure</CLabel>

                  </CCol>
                  <CCol xs="12" md="9">
                  <CSelect custom name="select" id="select">
                      <option value="0">Please select</option>
                      <option value="1">2 months</option>
                      <option value="2">3 months</option>
                      <option value="3">4 months</option>
                      <option value="3">5 months</option>
                      <option value="3">6 months</option>
                      <option value="3">7 months</option>
                      <option value="3">8 months</option>
                      <option value="3">9 months</option>
                      <option value="3">10 months</option>
                      <option value="3">11 months</option>

                      <option value="3">12 months</option>




                    </CSelect>
                  </CCol>
                 

                </CFormGroup>
                <hr />
                <div className="text-right">
                  <CButton size="md" color="dark" onClick={this.cal}>Calculate Loan</CButton>

                  </div>
                  <hr />
                  <p className="text-center font-weight-bold">
                    Loan Estimate Result
                  </p>
                  {this.state.load &&
                   <Loader
                   type="ThreeDots"
                   className="text-center"
                   height={60}
                   width={60}
                 />}
                 {this.state.show &&
                 <div>
                  <div className="d-flex justify-content-between">
                    <p>ACTUAL LOAN AMOUNT</p>
                    <p>50000</p>

                  </div>
                  <div className="d-flex justify-content-between">
                    <p> LOAN REPAYMENT ADDED INTEREST</p>
                    <p>15%</p>

                  </div>
                  <div className="d-flex justify-content-between">
                    <p> LOAN REPAYMENT AMOUNT</p>
                    <p>55000</p>

                  </div>
                  <div className="d-flex justify-content-between">
                    <p> GRAND TOTAL AMOUNT</p>
                    <p>55090</p>

                  </div>
                  </div>}
             
            </div>
          </Modal>
   
    
    </>
  )
}
}

export default Dashboard
