import React from 'react';
class Others extends React.Component{
    render(){
        return(
            <>
            <div>
                
            </div>
            </>
        )
    }
}
export default Others