import React from 'react';
import CNavbars from './base/navbars/Navbars'
 class Savings extends React.Component{
     render(){
         return(
             <>
         
                 <div className="borderNav pt-2" >
                     <p className="mr-auto pl-2">Accounts</p>
                     <p className="pr-3">Current And Savings</p>
                     <p className="pr-3">Term Depoists</p>
                     <p className="pr-3">Loans And Advances</p>
                     <p className="pr-3">Reciepts</p>
                   



                 </div>

         
             </>
         )
     }
 }
 export default Savings