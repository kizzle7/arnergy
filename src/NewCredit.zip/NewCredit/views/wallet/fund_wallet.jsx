import React, { lazy } from 'react'
import {
  CBadge,
  CButton,
  CButtonGroup,
  CCard,
  CCardFooter,
  CCol,
  CProgress,
  CRow,
  CCallout,
  CCardBody,
  CCardHeader,
  CListGroup,
  CListGroupItem,
  CTabContent,
  CFormGroup,
  CSelect,
  CForm,
  CLabel,
  CInput,
  CFormText,
  CTabPane
} from '@coreui/react'
import { Badge } from 'reactstrap';
import Loader from 'react-loader-spinner'
import {Modal} from 'antd'
import { InputGroup, InputGroupAddon, InputGroupText, Input, Label, FormFeedback, FormGroup } from 'reactstrap';
import CIcon from '@coreui/icons-react'
import '../../assets/font-awesome-4.7.0/css/font-awesome.min.css'

import MainChartExample from '../charts/MainChartExample.js'

const WidgetsDropdown = lazy(() => import('../widgets/WidgetsDropdown.js'))
const WidgetsBrand = lazy(() => import('../widgets/WidgetsBrand.js'))

class Fund extends React.Component{
  state = {
    select:  false,
    calculator:false,
    fundwallet: false,
    bankTransfer:false,
    atm: false,
    paystack:false,
    loader: false,
    cardpack:false,
    roller:false,
    home:false,
    amt: ''
  }

  componentWillMount =() => {
      this.setState({fundwallet: true})
  }
  fundclose= () => {
      this.setState({fundwallet: false})
  }

  loanCalculator =() => {
    this.setState({calculator: true})
  }

  calculatorclose =() => {
    this.setState({calculator:false})
  }

  fundwallet = () => {
    this.setState({fundwallet:true})
  }

  onChange = (e) => {
    if(e.target.value === "1"){
      this.setState({bankTransfer: true, fundwallet:false, atm:false})
    }
    else if(e.target.value === "2"){
      this.setState({atm: true, bankTransfer:false, fundwallet:false})
    }
    else{
        this.setState({bankTransfer:false, atm:false})
    }

   
  }

  change= (e) => {
    const {name, value} = e.target;
    this.setState({[name]: value})
  }
  loan = () =>{
    this.props.history.push('/loan_application')
  }
  atm = () => {
    sessionStorage.setItem('wallet', this.state.amt)
      this.setState({paystack: true, loader: true})
      setTimeout(() => {
          this.setState({loader: false, cardpack: true})
      },3000)

  }

  finish =() =>{
    this.setState({
      roller: true
    })
    setTimeout(()=> {
      this.setState({
        roller:false, home: true
      })
    }, 3000)
  }

  wal = () => {
    sessionStorage.setItem('amt', this.state.amt)
    this.props.history.push({
      pathname: '/dashboard',
    })
  }
  render(){
  return (
    <>
        {/* <div className="container"> 
         
         <div className="container text-center borderNav2">
             <div className="row">
                 <div className="col-md-6" style={{background:'red'}}>
                     <a href="/wallet_detail" className="text-white"><p className="pt-2">Wallet Details</p></a>
                 </div>
                 <div className="col-md-6">
                     <a href="/fund_your_wallet" className="text-warning"><p className="pt-2">Fund Wallet</p></a>
                 </div>
             </div>
         </div>
       </div> */}
                      <div className="container"> 
         
         <div className="container text-center borderNav2">
             <div className="row">
                 <div className="col-md-6 text-center" style={{background:''}}>
                     <a href="/wallet_detail" className="text-white text-center"><p className="pt-2">Wallet Details <span className=""> | </span></p></a>
                 </div>
                 <div className="col-md-6 text-center">
                     <a href="/fund_your_wallet" className="text-warning"><p className="pt-2  text-center">Fund Wallet <span className=""> | </span></p></a>
                 </div>
                
                 
             </div>
         </div>
       </div>
   
     
     
      
      <CRow className="pt-5">
      <CCol md="10" className="offset-1">
      <CCard className="mb-5 pb-2" style={{background:'white'}}>
            <CCardHeader style={{background:'white', color:'black'}}>
              <div className="d-flex justify-content-between">
              <small className="font-weight-bold">Fund My Wallet</small>

              </div>
             
            </CCardHeader>
            <CCardBody>
                {this.state.bankTransfer && 
                <div>
                <div>
                    <p className="font-weight-bold">To add money to your credit Go Africa Wallet, make a bank transfer of at least NGN100 from another account 
                        to the account details below. Funds should reflect in your wallet instantly.
                    </p>
                </div>
                <hr />
                <div className="text-center">
                    <h4 className="font-weight-bold">TRANSFER DETAILS</h4>
                    <p>The account below is fully functional, so you can even recieve payments from friends!.</p>
                </div>
                </div>
                }

                {this.state.atm &&
                <div>
              <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
                <CFormGroup row>
                  <CCol md="3">
                    <CLabel htmlFor="text-input">Amount To Pay</CLabel>
                  </CCol>
                  <CCol  md="9">
                    <CInput id="text-input" name="amt" onChange={this.change} placeholder="0.00" />
                  </CCol>
                  </CFormGroup>
                  <div className="text-right">
                  <CButton size="md" onClick={this.atm} color="dark">Pay</CButton>

                  </div>
                  </CForm>
           </div>
                
                }

                {this.state.paystack &&
                <div>
                    {this.state.loader &&
                     <Loader
                                type="TailSpin"
                                className="text-center"
                                height={60}
                                width={60}
                              />}
                              {this.state.cardpack &&
                    <CCol md="6" className="offset-3">
          <CCard>
            <CCardHeader>
              Credit/Debit Card Form
            </CCardHeader>
            <CCardBody>
              <CRow>
                <CCol xs="12">
                  <CFormGroup>
                    <CLabel htmlFor="name">Name</CLabel>
                    <CInput id="name" placeholder="Enter your name" required />
                  </CFormGroup>
                </CCol>
              </CRow>
              <CRow>
                <CCol xs="12">
                  <CFormGroup>
                    <CLabel htmlFor="ccnumber">Credit Card Number</CLabel>
                    <CInput id="ccnumber" placeholder="0000 0000 0000 0000" required />
                  </CFormGroup>
                </CCol>
              </CRow>
              <CRow>
                <CCol xs="4">
                  <CFormGroup>
                    <CLabel htmlFor="ccmonth">Month</CLabel>
                    <CSelect custom name="ccmonth" id="ccmonth">
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
                      <option value="9">9</option>
                      <option value="10">10</option>
                      <option value="11">11</option>
                      <option value="12">12</option>
                    </CSelect>
                  </CFormGroup>
                </CCol>
                <CCol xs="4">
                  <CFormGroup>
                    <CLabel htmlFor="ccyear">Year</CLabel>
                    <CSelect custom name="ccyear" id="ccyear">
                      <option>2017</option>
                      <option>2018</option>
                      <option>2019</option>
                      <option>2020</option>
                      <option>2021</option>
                      <option>2022</option>
                      <option>2023</option>
                      <option>2024</option>
                      <option>2025</option>
                      <option>2026</option>
                    </CSelect>
                  </CFormGroup>
                </CCol>
                <CCol xs="4">
                  <CFormGroup>
                    <CLabel htmlFor="cvv">CVV/CVC</CLabel>
                    <CInput id="cvv" placeholder="123" required/>
                  </CFormGroup>
                </CCol>
              </CRow>
            </CCardBody>
            
          </CCard>
          <div className="text-left">
            <CButton type="submit"  onClick={this.finish} size="sm" color="success"><CIcon name="cil-scrubber" /> Submit</CButton>

                  </div>
        </CCol>}
                </div>
                }


           
            </CCardBody>
          </CCard>
         
        </CCol>
    
         {this.state.bankTransfer &&
        <CCol md="6" className="offset-3">
        <CCard  className="pb-0">
            <CCardHeader>
            <small className="font-weight-bold ">ACCOUNT INFORMATION</small>
             
            </CCardHeader>
            <CCardBody>
            <div className="row">
                <div className="col-md-6">
                    <p className="font-weight-bold">BENEFICIARY</p>
                </div>
                <div className="col-md-6">
                    <p>MISHEAL HARRY</p>
                </div>
                <div className="col-md-6">
                    <p className="font-weight-bold">BANK NAME</p>
                </div>
                <div className="col-md-6">
                    <p>FIRSTOPTION MFB</p>
                </div>
                <div className="col-md-6">
                    <p className="font-weight-bold">ACCOUNTN NUMBER</p>
                </div>
                <div className="col-md-6">
                    <p>2117779451</p>
                </div>
            </div>
             
            </CCardBody>
          </CCard>
        </CCol>}
        </CRow>

        <Modal
            title={"Fund Wallet"}
            visible={this.state.fundwallet}
            onCancel={this.fundclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
            centered={true}
          >
            <div>
              <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
                
                <CFormGroup row>
                  <CCol md="5">
                    <CLabel htmlFor="text-input">Type of Wallet  Funding</CLabel>
                  </CCol>
                  <CCol  md="7">
                  <CSelect custom name="select" id="select" onChange={this.onChange}>
                                    <option value="0">Please select</option>
                                    <option value="1">Fund With Bank Transfer</option>
                                    <option value="2">Fund With Debit/Atm Card</option>
                                   
                 </CSelect>
                  </CCol>
                  </CFormGroup>
                 
                  </CForm>
             
             
            </div>
          </Modal>
          <Modal
            title={"Payment"}
            visible={this.state.roller}
            onCancel={this.fundclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
            centered={true}
          >
            <div>
              <p className="text-center">
                processing your fund payment...
              </p>
              <Loader
                                type="TailSpin"
                                className="text-center pt-2"
                                width={60}
                                height={60}
                              />
                              <hr />
             
             
            </div>
          </Modal>

          <Modal
            title={"Success"}
            visible={this.state.home}
            onCancel={this.fundclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
            centered={true}
          >
            <p>Your payment was successful, Your wallet has been funded with a sum of {this.state.amt} </p>
            <hr />
            <div className="text-center">

            <CButton type="submit" size="sm" color="success" onClick={this.wal}><CIcon name="cil-scrubber"  /> Goto Wallet</CButton>

             
            </div>
          </Modal>
   

    
    </>
  )
}
}

export default Fund
