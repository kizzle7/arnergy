import React from "react";
import {
  CRow,
  CCol,
  CCard,
  CCardHeader,
  CCardBody,
  CFormGroup,
  CLabel,
  CSelect,
  CFormText,
  CButton,
  CForm,
  CInput,
  CInputFile,
} from "@coreui/react";
import { Modal, Button } from "antd";
import Loader from "react-loader-spinner";
import { Alert } from "reactstrap";
import Cookie from "js-cookie";
import OtpInput from 'react-otp-input';
import Custom from './wallet_wizard'
class FundWallet extends React.Component {
  state = {
    modal: false,
    peronal: true,
    chooseBank: "",
    profile: false,
    emp: false,
    add: false,
    pas: Cookie.getJSON("user"),
    success: false,
    apply: true,
    loan: true,
    bank: false,
    check: false,
    load: false,
    congrats: false,
    maritalStatus: false,
    otherbanks: false,
    firstOption: false,
    mfbApi: false,
    mfbApii: false,
    spinMfb: false,
    spinMfbb: false,
    final: false,
    otp: false,
    OTP: '',
    summary:false,
    mfbApi2:false,
    spinMfb2:false
  };
  componentWillMount = () => {
    if (this.state.pas.username === "paschalovaga@gmail.com") {
      this.setState({
        modal: true,
      });
      setTimeout(() => {
        this.setState({ modal: false, profile: true });
      }, 3000);
    }
  };
 
  handleChange = otp => {
      this.setState({ OTP : otp });
      console.log(otp)
  }

  finalclose2 = () => {
      this.setState({
          summary:false, loan:true, otp:false
      })
  }

  marital = (e) => {
    if (e.target.value === "Married") {
      this.setState({
        maritalStatus: true,
      });
    }
  };

  next = () => {
    this.setState({ emp: true, peronal: false });
  };
  nexti = () => {
    this.setState({ add: true, peronal: false, emp: false });
  };

  nextii = () => {
    this.setState({ add: false, peronal: false, emp: false, other: true });
  };

  prev1 = () => this.setState({ peronal: true, emp: false, add: false });
  prev2 = () => this.setState({ peronal: false, emp: true, add: false });
  prev3 = (e) => {
    e.preventDefault();
    this.setState({ peronal: false, emp: false, add: true, other: false });
  };

  updatey = (e) => {
    e.preventDefault();
    this.setState({ success: true });
  };

  updateyclose = () => this.setState({ success: true });
  proceed = () =>
    this.setState({
      peronal: false,
      add: false,
      emp: false,
      success: false,
      pas: false,
    });

  nextbank = () => {
    this.setState({ loan: false, load: true });
    setTimeout(() => {
      this.setState({
        load: false,
        check: true,
      });
    }, 3500);
  };

  proceedbank = () => {
    this.setState({ check: false, bank: true, success: false });
  };
  final = () => {
    this.setState({ congrats: true, bank: false, loan: false });
    setTimeout(() => {
      this.setState({
        congrats: false,
        final: true,
      });
    }, 9000);
  };

  finalclose = () => this.setState({ final: false });

  finalproceed = () => {
    this.setState({ otp: true, loan: false, final: false });
  };

  finalproceed2 = () => {
      this.setState({summary: true})
  }

  bankStatement = (e) => {
    if (e.target.value === "1") {
      this.setState({
        firstOption: true,
        otherbanks: false,
        mfbApi: false,
        mfbApii: false,
        mfbApi2:false
      });
    } else if (e.target.value === "2") {
      this.setState({
        otherbanks: true,
        firstOption: false,
        mfbApi: false,
        mfbApii: false,
        mfbApi2:false
      });
    } else {
      this.setState({
        firstOption: false,
        otherbanks: false,
        mfbApi: false,
        mfbApii: false,
        mfbApi2:false
      });
    }
  };

  firstOption = (e) => {
    if (e.target.value.length > 7) {
      setTimeout(() => {
        this.setState({ spinMfb: true });
      }, 400);
      setTimeout(() => {
        this.setState({
          mfbApi: true,
          spinMfb: false,
        });
      }, 3500);
    } else {
      this.setState({ mfbApi: false, spinMfb: false });
    }
  };

  otherbank = (e) => {
    if (e.target.value === "33455556") {
        setTimeout(() => {
          this.setState({ spinMfb2: true });
        }, 400);
        setTimeout(() => {
          this.setState({
            mfbApi2: true,
            spinMfb2: false,
          });
        }, 3500);
      } else {
        this.setState({ mfbApi2: false, spinMfb2: false });
      }
  };

  otherbanks = (e) => {
    if (e.target.value.length > 8) {
      setTimeout(() => {
        this.setState({ spinMfbb: true });
      }, 400);
      setTimeout(() => {
        this.setState({
          mfbApii: true,
          spinMfbb: false,
        });
      }, 1500);
    } else {
      this.setState({ mfbApii: false, spinMfbb: false });
    }
  };

  render() {
    return (
      <>
        <div className="container"> 
         
          <div className="container text-center borderNav2">
              <div className="row">
                  <div className="col-md-6" style={{background:'red'}}>
                      <a href="#" className="text-white"><p className="pt-2">Wallet Details</p></a>
                  </div>
                  <div className="col-md-6">
                      <a href="/fund_your_wallet" className="text-white"><p className="pt-2">Fund Wallet</p></a>
                  </div>
              </div>
          </div>
        </div>
        <div className="pt-5 container">
          {this.state.pas.username === "paschalovaga@gmail.com" ? (
            <CRow>
              <CCol md="10 " className="offset-1">
                <CCard className="mb-5" style={{ background: "white" }}>
                  <CCardHeader style={{ background: "white", color: "black" }}>
                    <div className="d-flex justify-content-between">
                      <small className="font-weight-bold">
                        My Loan Application Profile
                      </small>
                    </div>
                  </CCardHeader>

                  <CCardBody>
                    {this.state.peronal && (
                      <div className="container">
                        <Custom step1 />
                        <CCard className="mb-5" style={{ background: "white" }}>
                          <CCardBody>
                            <CForm
                              action=""
                              method="post"
                              encType="multipart/form-data"
                              className="form-horizontal"
                            >
                              <div className="passport pb-3">
                                <div className="passport-box text-center">
                                  passport image
                                </div>
                              </div>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel>Gender</CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CSelect custom name="select" id="select">
                                    <option value="0">Please select</option>
                                    <option value="1">Male</option>
                                    <option value="2">Female</option>
                                  </CSelect>
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="text-input">
                                    Marital Status
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CSelect
                                    custom
                                    name="select"
                                    id="select"
                                    onChange={this.marital}
                                  >
                                    <option>Please select</option>
                                    <option>Single</option>
                                    <option>Married</option>
                                    <option>Divorced</option>
                                    <option>Separated</option>
                                  </CSelect>
                                </CCol>
                              </CFormGroup>
                              {this.state.maritalStatus && (
                                <div>
                                  <CFormGroup row>
                                    <CCol md="4">
                                      <CLabel htmlFor="email-input">
                                        Name of Spouse
                                      </CLabel>
                                    </CCol>
                                    <CCol md="8">
                                      <CInput
                                        type="email"
                                        id="email-input"
                                        name="email-input"
                                        autoComplete="email"
                                      />
                                    </CCol>
                                  </CFormGroup>
                                  <CFormGroup row>
                                    <CCol md="4">
                                      <CLabel htmlFor="email-input">
                                        Contact Phone Number
                                      </CLabel>
                                    </CCol>
                                    <CCol md="8">
                                      <CInput
                                        type="email"
                                        id="email-input"
                                        name="email-input"
                                        autoComplete="email"
                                      />
                                    </CCol>
                                  </CFormGroup>
                                  <CFormGroup row>
                                    <CCol md="4">
                                      <CLabel htmlFor="email-input">
                                        Number of Children
                                      </CLabel>
                                    </CCol>
                                    <CCol md="8">
                                      <CInput
                                        type="email"
                                        id="email-input"
                                        name="email-input"
                                        autoComplete="email"
                                      />
                                    </CCol>
                                  </CFormGroup>
                                </div>
                              )}
                              <div className="text-center">
                                <CButton
                                  type="submit"
                                  onClick={this.next}
                                  size="md"
                                  color="dark"
                                >
                                  Next
                                </CButton>
                              </div>
                            </CForm>
                          </CCardBody>
                        </CCard>
                      </div>
                    )}
                    {this.state.emp && (
                      <div className="container">
                        <Custom step1 step2 />
                        <CCard className="mb-5" style={{ background: "white" }}>
                          <CCardBody>
                            <CForm
                              action=""
                              method="post"
                              encType="multipart/form-data"
                              className="form-horizontal"
                            >
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel>Level of School</CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CSelect custom name="select" id="select">
                                    <option value="0">Please select</option>
                                    <option value="0">Phd</option>
                                    <option value="0">Degree</option>
                                    <option value="1">NCE</option>
                                    <option value="2">SSCE</option>
                                  </CSelect>
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="text-input">
                                    School Attended
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    Employment Status
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CSelect custom name="select" id="select">
                                    <option value="0">Please select</option>
                                    <option value="0">Self Employed</option>
                                    <option value="0">Bussiness Owners</option>
                                    <option value="1">Bussiness Owner</option>
                                    <option value="2">Employed</option>
                                    <option value="2">Student</option>
                                  </CSelect>
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    Bussiness Name/ Employer
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    How long have you been working there or
                                    doing the business?
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    Average Monthly Income
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <div className="text-center">
                                <CButton
                                  type="submit"
                                  size="md"
                                  color="dark"
                                  onClick={this.prev1}
                                >
                                  Previous
                                </CButton>{" "}
                                <CButton
                                  type="submit"
                                  onClick={this.nexti}
                                  size="md"
                                  color="dark"
                                >
                                  Next
                                </CButton>
                              </div>
                            </CForm>
                          </CCardBody>
                        </CCard>
                      </div>
                    )}
                    {this.state.add && (
                      <div className="container">
                        <Custom step1 step2 step3 />
                        <CCard className="mb-5" style={{ background: "white" }}>
                          <CCardBody>
                            <CForm className="form-horizontal">
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="text-input">
                                    Current Address
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    Closest Bus Stop
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>

                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    Local Govt Area
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">State</CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel>Type of Residence</CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CSelect custom name="select" id="select">
                                    <option>Please select</option>
                                    <option value="0">Rentage</option>
                                    <option value="1">Personal</option>
                                    <option value="2">Inherited</option>
                                  </CSelect>
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    Rent Per Annum
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    How long have you been living there?
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <div className="text-center">
                                <CButton
                                  type="submit"
                                  size="md"
                                  color="dark"
                                  onClick={this.prev2}
                                >
                                  Previous
                                </CButton>{" "}
                                <CButton
                                  size="md"
                                  color="dark"
                                  onClick={this.nextii}
                                >
                                  Next
                                </CButton>
                              </div>
                            </CForm>
                          </CCardBody>
                        </CCard>
                      </div>
                    )}
                    {this.state.other && (
                      <div className="container">
                        <Custom step1 step2 step3 step4 />
                        <CCard className="mb-5" style={{ background: "white" }}>
                          <CCardBody>
                            <CForm
                              action=""
                              method="post"
                              encType="multipart/form-data"
                              className="form-horizontal"
                            >
                              <p className="font-weight-bold text-center">
                                Identification
                              </p>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel>Means of Identification</CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CSelect custom name="select" id="select">
                                    <option value="0">Please select</option>
                                    <option value="0">PVC</option>
                                    <option value="0">Driving Licence</option>
                                    <option value="1">National ID Card</option>
                                    <option value="2">
                                      International Passport
                                    </option>
                                  </CSelect>
                                </CCol>
                              </CFormGroup>

                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    ID Number
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel htmlFor="email-input">
                                    Expiry Date
                                  </CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CInput
                                    type="email"
                                    id="email-input"
                                    name="email-input"
                                    autoComplete="email"
                                  />
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CLabel col md="4" htmlFor="file-input">
                                  Picture of ID
                                </CLabel>
                                <CCol md="8">
                                  <CInputFile
                                    id="file-input"
                                    name="file-input"
                                  />
                                </CCol>
                              </CFormGroup>
                              <hr />
                              <p className="font-weight-bold text-center">
                                Utitlity Bill
                              </p>
                              <CFormGroup row>
                                <CCol md="4">
                                  <CLabel>Type of Bill</CLabel>
                                </CCol>
                                <CCol md="8">
                                  <CSelect custom name="select" id="select">
                                    <option value="0">Please select</option>
                                    <option value="0">Waste Bill</option>
                                    <option value="0">PHCN Bill</option>
                                    <option>Water Bill</option>
                                  </CSelect>
                                </CCol>
                              </CFormGroup>
                              <CFormGroup row>
                                <CLabel col md="4" htmlFor="file-input">
                                  Picture of ID
                                </CLabel>
                                <CCol md="8">
                                  <CInputFile
                                    id="file-input"
                                    name="file-input"
                                  />
                                </CCol>
                              </CFormGroup>

                              <hr />
                              <p className="font-weight-bold text-center">
                                Personal Signature
                              </p>
                              <CFormGroup row>
                                <CLabel col md="4" htmlFor="file-input">
                                  Picture of Signature(Jpeg 20KB){" "}
                                </CLabel>
                                <CCol md="8">
                                  <CInputFile
                                    id="file-input"
                                    name="file-input"
                                  />
                                </CCol>
                              </CFormGroup>

                              <div className="text-center">
                                <CButton
                                  type="submit"
                                  size="md"
                                  color="dark"
                                  onClick={this.prev3}
                                >
                                  Previous
                                </CButton>{" "}
                                <CButton
                                  size="md"
                                  color="dark"
                                  onClick={this.updatey}
                                >
                                  Update Profile
                                </CButton>
                              </div>
                            </CForm>
                          </CCardBody>
                        </CCard>
                      </div>
                    )}
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>
          ) : (
            <CRow>
              <CCol md="10" className="offset-1">
                <CCard className="mb-5" style={{ background: "white" }}>
                  <CCardHeader style={{ background: "white", color: "black" }}>
                    <div className="d-flex justify-content-between">
                      <small className="font-weight-bold">My Loan</small>
                    </div>
                  </CCardHeader>
                  <CCardBody>
                    <p className="pb-1 text-center text-info">
                      {!this.state.bank
                        ? "Apply for Loan"
                        : "My Bank Statement"}
                    </p>

                    <div className="container">
                      <CCard className="mb-5" style={{ background: "white" }}>
                        <CCardBody>
                          {this.state.loan && (
                            <div>
                              <CForm
                                action=""
                                method="post"
                                encType="multipart/form-data"
                                className="form-horizontal"
                              >
                                <CFormGroup row>
                                  <CCol md="4">
                                    <CLabel>How much do you want?</CLabel>
                                  </CCol>
                                  <CCol md="8">
                                    <CInput
                                      type="email"
                                      id="email-input"
                                      name="email-input"
                                      autoComplete="email"
                                    />
                                  </CCol>
                                </CFormGroup>
                                <CFormGroup row>
                                  <CCol md="4">
                                    <CLabel htmlFor="text-input">Tenure</CLabel>
                                  </CCol>
                                  <CCol md="8">
                                    <CSelect custom name="select" id="select">
                                      <option value="0">Please select</option>
                                      <option value="1">2 Months</option>
                                      <option value="2">3 Months</option>
                                      <option value="2">4 Months</option>
                                      <option value="2">5 Months</option>
                                      <option value="2">6 Months</option>
                                      <option value="2">7 Months</option>
                                      <option value="2">8 Months</option>
                                      <option value="2">9 Months</option>
                                      <option value="2">10 Months</option>
                                      <option value="2">11 Months</option>
                                      <option value="2">12 Months</option>
                                    </CSelect>
                                  </CCol>
                                </CFormGroup>

                                <CFormGroup row>
                                  <CCol md="4">
                                    <CLabel htmlFor="email-input">
                                      Reason for taking loan?
                                    </CLabel>
                                  </CCol>
                                  <CCol md="8">
                                    <CSelect custom name="select" id="select">
                                      <option value="0">Please select</option>
                                      <option value="1">Education</option>
                                      <option value="2">Medical</option>
                                      <option value="2">Rent</option>
                                      <option value="2">Travel</option>
                                      <option value="2">Bussiness</option>
                                      <option value="2">Events</option>
                                      <option>household</option>
                                      <option>Other</option>
                                    </CSelect>
                                  </CCol>
                                </CFormGroup>
                                <div className="text-right">
                                  <CButton
                                    size="md"
                                    color="dark"
                                    onClick={this.nextbank}
                                  >
                                    Next
                                  </CButton>
                                </div>
                              </CForm>
                            </div>
                          )}
                          {this.state.load && (
                            <div>
                              <h4 className="font-weight-bold  text-center text-dark">
                                Calculating Loan Eligibity
                              </h4>
                              <Loader
                                type="ThreeDots"
                                className="text-center"
                                height={60}
                                width={60}
                              />
                            </div>
                          )}

                          {this.state.bank && (
                            <div>
                              <CForm
                                action=""
                                method="post"
                                encType="multipart/form-data"
                                className="form-horizontal"
                              >
                                <CFormGroup row>
                                  <CCol md="4">
                                    <CLabel>My Bank Statement Source</CLabel>
                                  </CCol>
                                  <CCol MD="8">
                                    <CSelect
                                      custom
                                      name="select"
                                      id="select"
                                      onChange={this.bankStatement}
                                    >
                                      <option value="0">Please select</option>
                                      <option value="1">
                                        FirstOption MFB Statment
                                      </option>
                                      <option value="2">
                                        OtherBank Statemnt
                                      </option>
                                    </CSelect>
                                  </CCol>
                                </CFormGroup>
                                {this.state.firstOption && (
                                  <CFormGroup row>
                                    <CCol md="4">
                                      <CLabel htmlFor="text-input">
                                        Account Number
                                      </CLabel>
                                    </CCol>
                                    <CCol md="8">
                                      <CInput
                                        type="email"
                                        id="email-input"
                                        name="email-input"
                                        autoComplete="email"
                                        onChange={this.firstOption}
                                      />
                                    </CCol>
                                  </CFormGroup>
                                )}
                                {this.state.mfbApi && (
                                  <div>
                                    <CFormGroup row>
                                      <CCol md="4">
                                        <CLabel htmlFor="text-input">
                                          Account Name
                                        </CLabel>
                                      </CCol>
                                      <CCol md="8">
                                        <CInput
                                          type="email"
                                          id="email-input"
                                          name="email-input"
                                          autoComplete="email"
                                          value={"PASCHAL NKEM OVAGA"}
                                        />
                                      </CCol>
                                    </CFormGroup>
                                    <CFormGroup row>
                                      <CCol md="4">
                                        <CLabel htmlFor="text-input">
                                          Bvn
                                        </CLabel>
                                      </CCol>
                                      <CCol md="8">
                                        <CInput
                                          type="email"
                                          id="email-input"
                                          name="email-input"
                                          autoComplete="email"
                                          value={"2573992015634"}
                                        />
                                      </CCol>
                                    </CFormGroup>
                                  </div>
                                )}
                                {this.state.spinMfb && (
                                  <Loader
                                    type="TailSpin"
                                    className="text-center pt-1"
                                    width={40}
                                    height={40}
                                  />
                                )}

                                {this.state.otherbanks && (
                                  <div>
                                    <CFormGroup row>
                                      <CCol md="4">
                                        <CLabel htmlFor="text-input">
                                          Account Number
                                        </CLabel>
                                      </CCol>
                                      <CCol md="8">
                                        <CInput
                                          type="email"
                                          id="email-input"
                                          name="email-input"
                                          autoComplete="email"
                                          onChange={this.otherbanks}
                                        />
                                      </CCol>
                                    </CFormGroup>
                                    <div></div>
                                    {this.state.mfbApii &&
                                    <CFormGroup row>
                                      <CCol md="4">
                                        <CLabel htmlFor="email-input">
                                          Bank Name
                                        </CLabel>
                                      </CCol>
                                      <CCol md="8">
                                        <CSelect
                                          custom
                                          name="chooseBank"
                                          id="select"
                                          onChange={this.otherbank}
                                        >
                                          <option value="33345559">
                                            Please select
                                          </option>
                                          <option value="33455559">
                                            GTB Bank
                                          </option>
                                          <option value="33455556">
                                            Zenith Bank
                                          </option>
                                         
                                        </CSelect>
                                      </CCol>
                                    </CFormGroup>}
                                    {this.state.spinMfbb && (
                                      <Loader
                                        type="TailSpin"
                                        className="text-center pt-1"
                                        width={40}
                                        height={40}
                                      />
                                    )}
                                    {this.state.mfbApi2 && (
                                      <CFormGroup row>
                                        <CCol md="4">
                                          <CLabel htmlFor="text-input">
                                            Bvn
                                          </CLabel>
                                        </CCol>
                                        <CCol md="8">
                                          <CInput
                                            type="email"
                                            id="email-input"
                                            name="email-input"
                                            autoComplete="email"
                                            value={"23765858575857"}
                                          />
                                        </CCol>
                                      </CFormGroup>
                                    )}
                                    {this.state.spinMfb2 && (
                                      <Loader
                                        type="TailSpin"
                                        className="text-center pt-1"
                                        width={40}
                                        height={40}
                                      />
                                    )}
                                  </div>
                                )}
                                <div className="text-right">
                                  <CButton
                                    size="md"
                                    color="dark"
                                    onClick={this.final}
                                  >
                                    Submit
                                  </CButton>
                                </div>
                              </CForm>
                            </div>
                          )}

                          {this.state.congrats && (
                            <div className="text-center">
                              <p className="text-cenmter">
                                Dear Customer, Hold On Few Moments...
                              </p>
                              <p className="text-cenmter">
                                Checking Statement of Accounts Thresholds And
                                Processesing Your Loan Application...
                              </p>
                              <Loader
                                type="TailSpin"
                                className="text-center pt-1"
                                width={60}
                                height={60}
                              />
                            </div>
                          )}
                          {this.state.otp && (
                            <div className=" text-center d-flex justify-content-center">
                                  <div>
                                      <p>Dear Customer, Kindly Input Otp.</p>
        <OtpInput
        value={this.state.OTP}
          onChange={this.handleChange}
          numInputs={6}
          inputStyle={{textAlign:'center', width:'6rem', height:'2rem'}}
          separator={<span>-</span>}
        />
           <div className="text-right mt-4">
                  <CButton
                    size="md"
                    color="dark"
                    className="text-right"
                    onClick={this.finalproceed2}
                  >
                    Proceed
                  </CButton>
                </div>
      </div>
                                </div>
             
                          )}
                        </CCardBody>
                      </CCard>
                    </div>
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>
          )}

          <Modal
            title={"Profile Creation Alert"}
            visible={this.state.modal}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
          >
            <div className="alert alert-info">
              <p>
                Dear Customer, We noticed your profile is not updated yet,
                Please kindly update your loan profile!
              </p>
            </div>
          </Modal>

          <Modal
            title={"Profile Update Success"}
            visible={this.state.success}
            onCancel={this.updateyclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
          >
            <div>
              <Alert color="success">
                <h4 className="alert-heading">Well done!</h4>
                <p>
                  Aww yeah,Dear Customer, you successfully updated your loan
                  account profile. Kindly proceed to apply for your loan.
                </p>
                <hr />
                <div className="text-right">
                  <CButton
                    size="md"
                    color="info"
                    className="text-right"
                    onClick={this.proceed}
                  >
                    Proceed
                  </CButton>
                </div>
              </Alert>
            </div>
          </Modal>

          <Modal
            title={"Loan Application Success"}
            visible={this.state.check}
            onCancel={this.updateyclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
          >
            <div>
              <Alert color="success">
                <h4 className="alert-heading">Congrats!</h4>
                <p>Dear Customer, your credit rating meets our requirements.</p>
                <hr />
                <div className="text-right">
                  <CButton
                    size="md"
                    color="info"
                    className="text-right"
                    onClick={this.proceedbank}
                  >
                    Proceed
                  </CButton>
                </div>
              </Alert>
            </div>
          </Modal>
          <Modal
            title={"Loan Approvement Information"}
            visible={this.state.final}
            onCancel={this.finalclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
          >
            <div>
              <Alert color="success">
                <h4 className="alert-heading">Congratulations</h4>
                <p>
                  Dear Customer, your loan application was successful, You are
                  eligible to get a loan from us, An OTP has been sent to your
                  phone, please proceed to validate.
                </p>
                <hr />
                <div className="text-right">
                  <CButton
                    size="md"
                    color="info"
                    className="text-right"
                    onClick={this.finalproceed}
                  >
                    Proceed
                  </CButton>
                </div>
              </Alert>
            </div>
          </Modal>

          <Modal
            title={"Loan Overview Summary"}
            visible={this.state.summary}
            onCancel={this.finalclose2}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
            width={700}
          >
            <div className="d-flex justify-content-between align-items-center">
                <p>NAME</p>
                <p>PASCHAL OVAGA IKEM</p>
            </div>
            <div className="d-flex justify-content-between align-items-center">
                <p>BANK NAME</p>
                <p>ZENITH BANK NIGERIA</p>
            </div>
            <div className="d-flex justify-content-between align-items-center">
                <p>EMPLOYMENT STATUS</p>
                <p>EMPLOYED</p>
            </div>
            <hr />
            <h4 className="text-center font-weight-bold " >Loan Informations</h4>
            <div className="d-flex justify-content-between align-items-center">
                <p>LOAN AMOUNT </p>
                <p>NGN150,000</p>
            </div>
            <div className="d-flex justify-content-between align-items-center">
                <p>LOAN TENURE</p>
                <p>4 months</p>
            </div>
            <hr />
            <h4 className="font-weight-bold text-center">
                Loan Repayment Informations
            </h4>
            <div>

            </div>
            <hr />
            <div className="text-center">
                <p className="text-success font-weight-bold">Dear Customer, The loan amount would be disbursed into your account in few moments</p>
                <p className="text-right success font-weight-bold">
                    Thank you.
                </p>

            </div>
          </Modal>
        </div>
      </>
    );
  }
}
export default FundWallet;
