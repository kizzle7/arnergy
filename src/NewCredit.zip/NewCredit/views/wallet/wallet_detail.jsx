import React, { lazy } from 'react'
import {
  CBadge,
  CButton,
  CButtonGroup,
  CCard,
  CCardFooter,
  CCol,
  CProgress,
  CRow,
  CCallout,
  CCardBody,
  CCardHeader,
  CListGroup,
  CListGroupItem,
  CTabContent,
  CTabPane
} from '@coreui/react'
import { Badge } from 'reactstrap';
import {Modal} from 'antd'
import { InputGroup, InputGroupAddon, InputGroupText, Input, Label, FormFeedback, FormGroup } from 'reactstrap';
import CIcon from '@coreui/icons-react'
import '../../assets/font-awesome-4.7.0/css/font-awesome.min.css'

import MainChartExample from '../charts/MainChartExample.js'

const WidgetsDropdown = lazy(() => import('../widgets/WidgetsDropdown.js'))
const WidgetsBrand = lazy(() => import('../widgets/WidgetsBrand.js'))

class Wallet_Detail extends React.Component{
  state = {
    select:  false,
    calculator:false
  }

  loanCalculator =() => {
    this.setState({calculator: true})
  }

  calculatorclose =() => {
    this.setState({calculator:false})
  }

  fundwallet = () => {
    this.props.history.push('/fund_your_wallet')
  }

  onChange = (e) => {
    if(e.target.value === "Account-01234673333"){
      this.setState({select: true})
    }
    else{
      this.setState({select: false})
    }
  }
  loan = () =>{
    this.props.history.push('/loan_application')
  }
  render(){
  return (
    <>
                 <div className="container"> 
         
         <div className="container text-center borderNav2">
             <div className="row">
                 <div className="col-md-6 text-center" style={{background:''}}>
                     <a href="/wallet_detail" className="text-warning text-center"><p className="pt-2">Wallet Details <span className=""> | </span></p></a>
                 </div>
                 <div className="col-md-6 text-center">
                     <a href="/fund_your_wallet" className="text-white"><p className="pt-2  text-center">Fund Wallet <span className=""> | </span></p></a>
                 </div>
                
                 
             </div>
         </div>
       </div>
   
     
     
      
      <CRow className="pt-5">
      <CCol md="10" className="offset-1">
      <CCard className="mb-5" style={{background:'white'}}>
            <CCardHeader style={{background:'white', color:'black'}}>
              <div className="d-flex justify-content-between">
              <small className="font-weight-bold">My Wallet </small>
              <small  className="font-weight-bold">JUNE 22 2020</small>
              </div>
             
            </CCardHeader>
            <CCardBody>
             <div className="d-flex justify-content-center align-items-center text-black">
               <small>Wallet Balance</small>

             </div>
             <div className="d-flex justify-content-center align-items-center text-white">
               <img src={require('../../img/naira.svg')}  width="5%" />
               <p className="font-weight-bold text-center h4 pt-2" style={{color:'black'}}>0.00</p>

            
             </div>
             <div className="text-center font-weight-bold pb-4">
             <CButton size="sm" onClick={this.fundwallet} className="mt-2"  color="dark">Fund Wallet</CButton>

             </div>
         

            </CCardBody>
          </CCard>
         
        </CCol>
    

        <CCol md="10" className="offset-1">
        <CCard  className="pb-0">
            <CCardHeader>
            <small className="font-weight-bold ">RECENT ACTIVITY</small>
             
            </CCardHeader>
            <CCardBody>
            <p className="text-center text-black">No recent activity</p>
             
            </CCardBody>
          </CCard>
        </CCol>
        </CRow>

        <Modal
            title={"Loan Calculator"}
            visible={this.state.calculator}
            onCancel={this.calculatorclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
            centered={true}
          >
            <div>
             <p className="font-weight-bold text-center">Calculate A Loan </p>
             
            </div>
          </Modal>
   
    
    </>
  )
}
}

export default Wallet_Detail
