import React from "react";
import {
  CRow,
  CCol,
  CCard,
  CCardBody,
  CCardHeader,
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
  CNav,
  CNavItem,
  CFormGroup,
  CForm,
  CLabel,
  CInput,
  CFormText,
  CSelect,
  CTextarea,
  CNavLink,
  CCardFooter,
  CInputCheckbox,
  CButton,
} from "@coreui/react";
import { Card } from "reactstrap";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { Modal } from "antd";
class AirtimePurchase extends React.Component {
    state = {
      updateCheck: false,
      updateCheck2: false,
      mtn: false,
      glo: false,
      airtel: false,
      eti: false,
      buy: false,
    };
  
    mtn = () => {
      this.setState({ mtn: true, glo: false, airtel: false, eti: false });
    };
  
    glo = () => {
      this.setState({ mtn: false, glo: true, airtel: false, eti: false });
    };
  
    airtel = () => {
      this.setState({ mtn: false, glo: false, airtel: true, eti: false });
    };
  
    eti = () => {
      this.setState({ mtn: false, glo: false, airtel: false, eti: true });
    };
  
    checkChange = (e) => {
      const { name, checked } = e.target;
      if (checked) {
        this.setState({ updateCheck: true, updateCheck2: false });
      }
    };
  
    checkChange2 = (e) => {
      const { name, checked } = e.target;
      if (checked) {
        this.setState({ updateCheck2: true, updateCheck: false });
      }
    };
    buyClose = () => {
      this.setState({buy:false})
    }
  
    buy = (e) => {
      e.preventDefault()
      this.setState({ buy: true });
    };
    render() {
      return (
        <>
          <div className="offset-2 col-md-8">
            <CRow className="pt-3">
              <CCol md="12">
                <CCard>
                  <CCardBody>
                    <CForm
                      action=""
                      method="post"
                      encType="multipart/form-data"
                      className="form-horizontal"
                    >
                      <h2>Buy Airtime</h2>
                      <CFormGroup row>
                        <CCol md="4">
                          <CLabel htmlFor="text-input">Select Network</CLabel>
                        </CCol>
                        <CCol md="8">
                          <div className="12">
                            <div className="row">
                              <CCol md="3">
                                <Card className="point" onClick={this.mtn}>
                                  <div className="text-center">
                                    <img
                                      src={require("../../img/mtnAirtime.png")}
                                      width="45%"
                                      className="pt-3 pb-3 text-info"
                                    />
                                  </div>
                                </Card>
                              </CCol>
                              <CCol md="3">
                                <Card className="point" onClick={this.glo}>
                                  <div className="text-center">
                                    <img
                                      src={require("../../img/gloAirtime.jpg")}
                                      width="45%"
                                      className="pt-3 pb-3 text-info"
                                    />
                                  </div>
                                </Card>
                              </CCol>
                              <CCol md="3">
                                <Card className="point" onClick={this.eti}>
                                  <div className="text-center">
                                    <img
                                      src={require("../../img/9mobileAirtime.png")}
                                      width="43%"
                                      className="pt-3 pb-4 text-info"
                                    />
                                  </div>
                                </Card>
                              </CCol>
                              <CCol md="3">
                                <Card className="point" onClick={this.airtel}>
                                  <div className="text-center">
                                    <img
                                      src={require("../../img/airtelAirtime.png")}
                                      width="45%"
                                      className="pt-3 pb-3 text-info"
                                    />
                                  </div>
                                </Card>
                              </CCol>
                            </div>
                          </div>
                        </CCol>
                        {this.state.mtn && (
                          <CCol className="col-md-4 offset-4">
                            <p className="font-weight-bold">MTN NIGERIA</p>
                          </CCol>
                        )}
                        {this.state.glo && (
                          <CCol className="col-md-4 offset-4">
                            <p className="font-weight-bold">GLO MOBILE</p>
                          </CCol>
                        )}
                        {this.state.eti && (
                          <CCol className="col-md-4 offset-4">
                            <p className="font-weight-bold">9MOBILE</p>
                          </CCol>
                        )}
                        {this.state.airtel && (
                          <CCol className="col-md-4 offset-4">
                            <p className="font-weight-bold">AIRTEL NG</p>
                          </CCol>
                        )}
                      </CFormGroup>
  
                      <CFormGroup row>
                        <CCol md="4">
                          <CLabel htmlFor="text-input" className="pt-0"></CLabel>
                        </CCol>
                        <CCol md="8">
                          <FormControlLabel
                            className="pl-0"
                            control={
                              <Checkbox
                                checked={this.state.updateCheck}
                                className="ml-0"
                                onChange={this.checkChange}
                                name="updateCheck"
                                color="primary"
                              />
                            }
                            label="Recharge Self"
                          />
                          <FormControlLabel
                            className="pl-0"
                            control={
                              <Checkbox
                                checked={this.state.updateCheck2}
                                className="ml-0"
                                onChange={this.checkChange2}
                                name="updateCheck2"
                                color="primary"
                              />
                            }
                            label="Recharge Others"
                          />
                        </CCol>
                      </CFormGroup>
                      {this.state.updateCheck2 && (
                        <CFormGroup row>
                          <CCol md="4">
                            <CLabel htmlFor="text-input" className="pt-2">
                              Phone Number{" "}
                            </CLabel>
                          </CCol>
                          <CCol md="8">
                            <CInput id="text-input" name="text-input" />
                          </CCol>
                        </CFormGroup>
                      )}
                      <CFormGroup row className="pt-2">
                        <CCol md="4">
                          <CLabel htmlFor="text-input" className="pt-2">
                            Amount
                          </CLabel>
                        </CCol>
                        <CCol md="4">
                          <CInput
                            id="text-input"
                            name="text-input"
                            placeholder="NGN"
                          />
                        </CCol>
                      </CFormGroup>
                      <CFormGroup row className="">
                        <CCol md="4">
                          <CLabel htmlFor="text-input" className="pt-1"></CLabel>
                        </CCol>
                        <CCol md="4">
                          {this.state.updateCheck2 && (
                            <FormControlLabel
                              className="text-center"
                              control={
                                <Checkbox
                                  checked={this.state.updateChecki}
                                  className="ml-0"
                                  name="updateCheck"
                                  color="primary"
                                />
                              }
                              label="Save as Beneficiary"
                            />
                          )}
                        </CCol>
                      </CFormGroup>
                      <div className="text-center">
                        <CButton
                          type="submit"
                          size="md"
                          color="dark"
                          onClick={this.buy}
                        >
                          {" "}
                          Buy
                        </CButton>
                      </div>
                    </CForm>
                  </CCardBody>
                </CCard>
              </CCol>
            </CRow>
          </div>
          <Modal
            title="Security Question and PIN Confirmation"
            visible={this.state.buy}
            // onOk={this.singleTerminal}
            onCancel={this.buyClose}
            footer={null}
            okText="Add Terminal"
            cancelText="Clear"
            maskClosable={false}
            centered={true}
          >
           
            <p className="font-weight-bold text-center">PIN</p>
            <CFormGroup row>
              <CCol md="7">
                <CLabel htmlFor="text-input">Input PIN</CLabel>
              </CCol>
              <CCol md="5">
                <CInput id="text-input" name="text-input" />
              </CCol>
            </CFormGroup>
            <div className="text-center">
              <CButton
                type="submit"
                size="lg"
                color="success"
                onClick={this.sendOwn}
              >
                {" "}
                Submit
              </CButton>
            </div>
          </Modal>
        </>
      );
    }
  }
export default AirtimePurchase