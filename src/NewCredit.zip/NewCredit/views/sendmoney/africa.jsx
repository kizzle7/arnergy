import React from 'react';
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    
  } from '@coreui/react'
  import {Modal} from 'antd';
  import {Alert } from 'reactstrap'
  import Loader from 'react-loader-spinner'
  import CIcon from '@coreui/icons-react'

  class Africa extends React.Component{

    state = {
        name: false,
        spin: false,
        send: false,
        load:false,
        show:false,
        sendingname: "PASCHAL IKEM OVAGA",
        amt: ''
    }

    onChange = (e) => {
        const {name, value} = e.target;
        this.setState({[name]: value})
        if (e.target.value.length > 10) {
            setTimeout(() => {
              this.setState({ spin: true });
            }, 400);
            setTimeout(() => {
              this.setState({
                name: true,
                spin: false,
              });
            }, 3500);
          } else {
            this.setState({ name: false, spin:false});
          }

    }

    send = () => {
        this.setState({send: true, load: true})
        setTimeout(() => {
            this.setState({
                load:false, show:true
            })
        },3000)
    }

    closer = () => this.setState({send:false})
    render(){

     
        return(
            <>
          {/* <div className="container">
                <div className="borderNav pt-2">
                    <a href="/loans"><p className="pl-5">Within Nigeria</p></a>
                    <p>Within Africa</p>
                    <p>Multiple Transfers</p>
                    <p className="pr-5">Manage Saved beneficiaries</p>
                </div>
            </div> */}
                        <div className="container"> 
         
         <div className="container text-center borderNav2">
             <div className="row">
                 <div className="col-md-4 text-center" style={{background:''}}>
                     <a href="/send_money_nigeria" className="text-white text-center"><p className="pt-2">Within Nigeria <span className=""> | </span></p></a>
                 </div>
                 <div className="col-md-4 text-center">
                     <a href="/africa" className="text-warning"><p className="pt-2  text-center">Within Africa <span className=""> | </span></p></a>
                 </div>
                
                 <div className="col-md-4" style={{background: 'grey'}}>
                     <a href="/beneficiaries" className="text-white"><p className="pt-2">Saved Beneficiaries <span className="pl-2"> | </span></p></a>
                 </div>
             </div>
         </div>
       </div>

            <div className="pt-5 container"> 
                <CRow>
                    <CCol md="10" className="offset-1">
          <CCard>
            <CCardHeader>
              Send Money Within Africa
            </CCardHeader>
            <CCardBody>
              <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
               
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input" >Beneficiary Account Number</CLabel>
                  </CCol>
                  <CCol xs="12" md="8">
                    <CInput id="text-input" name="text-input" onChange={this.onChange} />
                  </CCol>
                </CFormGroup>
                {this.state.name &&
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Beneficiary Name</CLabel>
                  </CCol>
                  <CCol xs="12" md="8">
                    <CInput id="text-input" name="text-input" value={this.state.sendingname} />
                  </CCol>
                </CFormGroup>}
                {this.state.spin &&  <Loader
                                type="TailSpin"
                                className="text-center pb-3"
                                height={40}
                                width={35}
                              />}
                
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="select">Select Bank</CLabel>
                  </CCol>
                  <CCol xs="4" md="8">
                    <CSelect custom name="select" id="select">
                      <option value="0">Please select</option>
                      <option value="1">Zenith Bank</option>
                      <option value="2">First Bank</option>
                      <option value="3">UBA</option>
                    </CSelect>
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Amount</CLabel>
                  </CCol>
                  <CCol xs="12" md="8">
                    <CInput id="text-input" name="amt" onChange={this.onChange} />
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Payment Remarks</CLabel>
                  </CCol>
                  <CCol xs="12" md="8">
                    <CInput id="text-input" name="text-input" />
                  </CCol>
                </CFormGroup>
                
              
               
                
              </CForm>
            </CCardBody>
            <CCardFooter>
              <CButton type="submit" size="md" color="danger" onClick={this.send}> Send</CButton>
            </CCardFooter>
          </CCard>
        </CCol>
                    
                
                </CRow>
            </div>

            <Modal
            title={"Sending Money"}
            visible={this.state.send}
            onCancel={this.closer}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
          >
            <div>
                
                  <hr />
                  <p className="text-center font-weight-bold">
                    Sending Status
                  </p>
                  {this.state.load &&
                  <div className="text-center">
                                  <p >Sending...</p>
                   <Loader
                   type="ThreeDots"
                   className="text-center"
                   height={60}
                   width={60}
                 />
                 </div>
                 }
                 {this.state.show &&
                 <Alert color="success">
                 <h4 className="alert-heading">successful</h4>
                 <p>
                   Dear Customer, you have successfully sent a sum of <b>{this.state.amt}</b> to <b>{this.state.sendingname}</b> was successful
                 </p>
               
               </Alert>
                  }
             
            </div>
          </Modal>
            </>
        )
    }
}
export default Africa