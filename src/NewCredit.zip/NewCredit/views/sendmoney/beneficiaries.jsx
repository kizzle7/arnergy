import React from 'react';
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    
  } from '@coreui/react'
  import {Modal} from 'antd';
  import {Alert } from 'reactstrap'
  import Loader from 'react-loader-spinner'
  import CIcon from '@coreui/icons-react'

  class Beneficiaries extends React.Component{

    state = {
        name: false,
        spin: false,
        send: false,
        load:false,
        show:false,
        sendingname: "PASCHAL IKEM OVAGA",
        amt: ''
    }

    onChange = (e) => {
        const {name, value} = e.target;
        this.setState({[name]: value})
        if (e.target.value.length > 10) {
            setTimeout(() => {
              this.setState({ spin: true });
            }, 400);
            setTimeout(() => {
              this.setState({
                name: true,
                spin: false,
              });
            }, 3500);
          } else {
            this.setState({ name: false, spin:false});
          }

    }

    send = () => {
        this.setState({send: true, load: true})
        setTimeout(() => {
            this.setState({
                load:false, show:true
            })
        },3000)
    }

    closer = () => this.setState({send:false})
    render(){

     
        return(
            <>
          {/* <div className="container">
                <div className="borderNav pt-2">
                    <a href="/loans"><p className="pl-5">Within Nigeria</p></a>
                    <p>Within Africa</p>
                    <p>Multiple Transfers</p>
                    <p className="pr-5">Manage Saved beneficiaries</p>
                </div>
            </div> */}
                         <div className="container"> 
         
         <div className="container text-center borderNav2">
             <div className="row">
                 <div className="col-md-4 text-center" style={{background:''}}>
                     <a href="/send_money_nigeria" className="text-white text-center"><p className="pt-2">Within Nigeria <span className=""> | </span></p></a>
                 </div>
                 <div className="col-md-4 text-center">
                     <a href="/africa" className="text-white"><p className="pt-2  text-center">Within Africa <span className=""> | </span></p></a>
                 </div>
                
                 <div className="col-md-4" style={{background: 'grey'}}>
                     <a href="/beneficiaries" className="text-warning"><p className="pt-2">Saved Beneficiaries <span className="pl-2"> | </span></p></a>
                 </div>
             </div>
         </div>
       </div>

            <div className="pt-5 container"> 
                <CRow>
                <CCol md="10" className="offset-1" >
      <CCard className="mb-5" style={{background:'white'}}>
            <CCardHeader style={{background:'white', color:'black'}}>
              <div className="d-flex justify-content-between">
              <small className="font-weight-bold">Beneficiaries </small>
              <small  className="font-weight-bold">JUNE 22 2020</small>
              </div>
             
            </CCardHeader>
            <CCardBody>
    
             <div className="row">
             <div className="col-md-2">
                  <p className="font-weight-bold">S/N</p>
              </div>
              <div className="col-md-2">
                  <p className="font-weight-bold">Name of Beneficiary</p>
              </div>
              <div className="col-md-3">
                  <p className="font-weight-bold">Beneficiary Account</p>
              </div>
              <div className="col-md-3">
                  <p className="font-weight-bold" >Beneficiary Bank</p>
              </div>
           
            
          </div>
          <div className="row">
          <div className="col-md-2">
                  <p className="font-weight-bold">1</p>
              </div>
              <div className="col-md-2">
                  <p>Paschal Ikem</p>
              </div>
              <div className="col-md-3">
                  <p>3023687815</p>
              </div>
              <div className="col-md-3">
                  <p>First Option MFB</p>
              </div>  
          </div>
          <div className="row">
          <div className="col-md-2">
                  <p className="font-weight-bold">2</p>
              </div>
              <div className="col-md-2">
                  <p>05/05/2020</p>
              </div>
              <div className="col-md-3">
                  <p>Medical</p>
              </div>
              <div className="col-md-3">
                  <p>450,000</p>
              </div>
              <div className="col-md-2">
                  <p className="text-success">successful</p>
              </div>
              
          </div>
          <div className="row">
          <div className="col-md-2">
                  <p className="font-weight-bold">3</p>
              </div>
              <div className="col-md-2">
                  <p>17/05/2019</p>
              </div>
              <div className="col-md-3">
                  <p>Rent</p>
              </div>
              <div className="col-md-3">
                  <p>350,000</p>
              </div>
              <div className="col-md-2">
                  <p className="text-success">successful</p>
              </div>
            
          </div>

          <div className="row">
          <div className="col-md-2">
                  <p className="font-weight-bold">4</p>
              </div>
              <div className="col-md-2">
                  <p>20/04/2019</p>
              </div>
              <div className="col-md-3">
                  <p>Education</p>
              </div>
              <div className="col-md-3">
                  <p>700,000</p>
              </div>
              <div className="col-md-2">
                  <p className="text-success">successful</p>
              </div>
              
          </div>
        
         
               
               

            </CCardBody>
          </CCard>
        
         
        </CCol>
                    
                
                </CRow>
            </div>

            <Modal
            title={"Sending Money"}
            visible={this.state.send}
            onCancel={this.closer}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
          >
            <div>
                
                  <hr />
                  <p className="text-center font-weight-bold">
                    Sending Status
                  </p>
                  {this.state.load &&
                  <div className="text-center">
                                  <p >Sending...</p>
                   <Loader
                   type="ThreeDots"
                   className="text-center"
                   height={60}
                   width={60}
                 />
                 </div>
                 }
                 {this.state.show &&
                 <Alert color="success">
                 <h4 className="alert-heading">successful</h4>
                 <p>
                   Dear Customer, you have successfully sent a sum of <b>{this.state.amt}</b> to <b>{this.state.sendingname}</b> was successful
                 </p>
               
               </Alert>
                  }
             
            </div>
          </Modal>
            </>
        )
    }
}
export default Beneficiaries