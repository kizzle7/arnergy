import React, { lazy } from 'react'
import {
  CBadge,
  CButton,
  CButtonGroup,
  CCard,
  CCardFooter,
  CCol,
  CProgress,
  CRow,
  CCallout,
  CCardBody,
  CCardHeader,
  CListGroup,
  CListGroupItem,
  CTabContent,
  CFormGroup,
  CForm,
  
  CSelect,
  CLabel,
  CTabPane
} from '@coreui/react'
import { Badge } from 'reactstrap';
import {Modal} from 'antd'
import { InputGroup, InputGroupAddon, InputGroupText, Input, Label, FormFeedback, FormGroup } from 'reactstrap';
import CIcon from '@coreui/icons-react'
import '../../assets/font-awesome-4.7.0/css/font-awesome.min.css'

import MainChartExample from '../charts/MainChartExample.js'

const WidgetsDropdown = lazy(() => import('../widgets/WidgetsDropdown.js'))
const WidgetsBrand = lazy(() => import('../widgets/WidgetsBrand.js'))

class Loan_Status extends React.Component{
  state = {
    select:  false,
    calculator:false,
    select1:false,
    select2:false,
    select3:false,
    show:true
  }

  loanCalculator =() => {
    this.setState({calculator: true})
  }

  calculatorclose =() => {
    this.setState({calculator:false})
  }

  fundwallet = () => {
    this.props.history.push('/fund_your_wallet')
  }

  onChange = (e) => {
    if(e.target.value === "1"){
      this.setState({select1: true, select2:false, select3:false, show: true})
    }
    else if(e.target.value === "2"){
      this.setState({select2: true, select1: false, select3: false, show: true})
    }
    else if(e.target.value === "3"){
        this.setState({select3: true, select1: false, select2:false, show: true})
    }
    else{
        this.setState({select3: false, select1: false, select2:false})

        
    }
  }
  loan = () =>{
    this.props.history.push('/loan_application')
  }
  render(){
  return (
    <>
       <div className="container"> 
         
         <div className="container text-center borderNav2">
             <div className="row">
                 <div className="col-md-4 text-center" style={{background:''}}>
                     <a href="/my_loans" className="text-white text-center"><p className="pt-2">My Loans <span className=""> | </span></p></a>
                 </div>
                 <div className="col-md-4 text-center">
                     <a href="/loan_application" className="text-white"><p className="pt-2  text-center">Loan Application <span className=""> | </span></p></a>
                 </div>
                
                 <div className="col-md-4" style={{background: 'grey'}}>
                     <a href="/loan_status" className="text-warning"><p className="pt-2">Loan Status <span className="pl-2"> | </span></p></a>
                 </div>
             </div>
         </div>
       </div>
   
     
     
      
      <CRow className="pt-5">
      <CCol md="10" className="offset-1">
      <CCard className="mb-5" style={{background:'white'}}>
            <CCardHeader style={{background:'white', color:'black'}}>
              <div className="d-flex justify-content-between">
              <small className="font-weight-bold">My Loan Status </small>
              <small  className="font-weight-bold">JUNE 22 2020</small>
              </div>
             
            </CCardHeader>
            <CCardBody>
             <div className="d-flex justify-content-center align-items-center text-black">
               <small>Loans Status</small>

             </div>
             <div className="d-flex justify-content-center align-items-center text-white">
             <CButton type="submit" size="sm" color="primary"><CIcon name="cil-notes" /></CButton> 
            
             </div>
             <div className="text-center font-weight-bold pb-4">
             <CButton size="sm" onClick={this.loanCalculator} className="mt-2"  color="dark">SEE LOAN INFORMATIONS</CButton>

             </div>
         

            </CCardBody>
          </CCard>
         
        </CCol>
    

        <CCol md="10" className="offset-1">
        <CCard  className="pb-0">
            <CCardHeader>
            <small className="font-weight-bold ">RECENT ACTIVITY</small>
             
            </CCardHeader>
            <CCardBody>
            {!this.state.show ? 
            <p className="text-center text-black">No Loan Selected Yet</p> :
             <div>
                 {this.state.select1 &&
                <div>
                    <div className="d-flex justify-content-between">
                   <p>LOAN DATE </p>
                   <p>02/04/2020</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p>ACTUAL LOAN AMOUNT </p>
                   <p>50000</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> LOAN REPAYMENT ADDED INTEREST</p>
                   <p>15%</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> LOAN REPAYMENT AMOUNT</p>
                   <p>55000</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> GRAND TOTAL AMOUNT</p>
                   <p>55090</p>

                 </div>
                 </div>}
                
                {this.state.select2 &&
                <div>
                 <div className="d-flex justify-content-between">
                   <p>LOAN DATE </p>
                   <p>04/05/2020</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p>ACTUAL LOAN AMOUNT </p>
                   <p>50000</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> LOAN REPAYMENT ADDED INTEREST</p>
                   <p>15%</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> LOAN REPAYMENT AMOUNT</p>
                   <p>55000</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> GRAND TOTAL AMOUNT</p>
                   <p>55090</p>

                 </div>
                 </div>}
                
                {this.state.select3 &&
                <div>
                     <div className="d-flex justify-content-between">
                   <p>LOAN DATE </p>
                   <p>06/05/2020</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p>ACTUAL LOAN AMOUNT</p>
                   <p>50000</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> LOAN REPAYMENT ADDED INTEREST</p>
                   <p>15%</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> LOAN REPAYMENT AMOUNT</p>
                   <p>55000</p>

                 </div>
                 <div className="d-flex justify-content-between">
                   <p> GRAND TOTAL AMOUNT</p>
                   <p>55090</p>

                 </div>
                 </div>}
                 </div>}
             
            </CCardBody>
          </CCard>
        </CCol>
        </CRow>

        <Modal
            title={"Select Loan"}
            visible={this.state.calculator}
            onCancel={this.calculatorclose}
            footer={null}
            cancelText="Clear"
            maskClosable={false}
            centered={true}
          >
            <div>
            <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
                
                <CFormGroup row>
                  <CCol md="5">
                    <CLabel htmlFor="text-input">Select Loan To View</CLabel>
                  </CCol>
                  <CCol  md="7">
                  <CSelect custom name="select" id="select" onChange={this.onChange}>
                                    <option value="0">Please select</option>
                                    <option value="1">Loan -02/3/2020</option>
                                    <option value="2">Loan -04/05/2020</option>
                                    <option value="3">Loan -06/05/2020</option>

                                   
                 </CSelect>
                  </CCol>
                  </CFormGroup>
                 
                  </CForm>
             
            </div>
          </Modal>
   
    
    </>
  )
}
}

export default Loan_Status
