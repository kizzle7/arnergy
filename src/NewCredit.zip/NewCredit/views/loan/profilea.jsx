import React, { Component } from 'react';
import { CRow, CCol ,CCard, CCardHeader, CCardBody, CFormGroup, CLabel, CSelect, CForm,CInput,CFormText} from '@coreui/react';


class Personal extends Component {
    render() {
        return (
            <div className="container">
                 <CCard className="mb-5" style={{background:'white'}}>
            
         
            <CCardBody>
              <CForm action="" method="post" encType="multipart/form-data" className="form-horizontal">
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel>Gender</CLabel>
                  </CCol>
                  <CCol  md="8">
                  <CSelect custom name="select" id="select">
                      <option value="0">Please select</option>
                      <option value="1">Male</option>
                      <option value="2">Female</option>
                    </CSelect>                 
                     </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="text-input">Marital Status</CLabel>
                  </CCol>
                  <CCol  md="8">
                  <CSelect custom name="select" id="select">
                      <option value="0">Please select</option>
                      <option value="1">Single</option>
                      <option value="2">Married</option>
                      <option value="2">Divorced</option>
                      <option value="2">Separated</option>

                    </CSelect>                  
                    </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="email-input">Name of Spouse</CLabel>
                  </CCol>
                  <CCol  md="8">
                    <CInput type="email" id="email-input" name="email-input" autoComplete="email"/>
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="email-input">Contact Phone Number</CLabel>
                  </CCol>
                  <CCol  md="8">
                    <CInput type="email" id="email-input" name="email-input" autoComplete="email"/>
                  </CCol>
                </CFormGroup>
                <CFormGroup row>
                  <CCol md="4">
                    <CLabel htmlFor="email-input">Number of Children</CLabel>
                  </CCol>
                  <CCol  md="8">
                    <CInput type="email" id="email-input" name="email-input" autoComplete="email"/>
                  </CCol>
                </CFormGroup>
                </CForm>
             
          
            </CCardBody>
          </CCard>
                

            </div>
        );
    }
}

export default Personal;