import React, { Component } from 'react';

class CustomLoan extends Component {
    render() {
        return (
            <div className="checkout">
                <div className={this.props.step1 ? 'active': ''}>Applying</div>
                <div className={this.props.step2 ? 'active': ''}>Loan Details</div>
             

            </div>
        );
    }
}

export default CustomLoan;