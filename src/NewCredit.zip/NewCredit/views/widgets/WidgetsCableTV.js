import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsCableTV = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/dstv.png')} width="60%" className="pt-3 pb-3 text-info" />
        </div>
     
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/gotv.jpg')} width="60%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/startimes.jpg')} width="43%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/actv.jpg')} width="70%" className="pt-3 pb-3" />
        </div>
   
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/irokotv.png')} width="50%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/infinitytv.jpg')} width="70%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/montagetv.png')} width="25%" className="pt-3 pb-3" />
        </div>
    
      </Card>
      </CCol>


      
    </CRow>
  )
}

export default WidgetsCableTV
