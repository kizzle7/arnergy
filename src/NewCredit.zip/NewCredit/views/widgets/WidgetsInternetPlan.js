import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsInternetPlan = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/mtnDataplan.jpg')} width="35%" className="pt-3 pb-3 text-info" />
        </div>
     
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/gloDataplan.jpg')} width="35%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/9mobileDataplan.jpg')} width="66%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/airtelDataplan.jpg')} width="66%" className="pt-3 pb-3" />
        </div>
   
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/smileData.jpg')} width="67%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/swiftData.png')} width="82%" className="pt-3 pb-3" />
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/spectranetData.jpg')} width="60%" className="pt-3 pb-3" />
        </div>
    
      </Card>
      </CCol>
      


      
    </CRow>
  )
}

export default WidgetsInternetPlan
