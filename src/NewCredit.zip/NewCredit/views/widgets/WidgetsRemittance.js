import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsRemittance = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="8" lg="4">
      <Card>
        <div className="text-center">
        <img src={require('../../img/westernUnion.png')} width="20%" className="pt-3 text-info" />
        <p className="font-weight-bold text-center" >Western Union</p>
        </div>
     
      </Card>
      </CCol>
      <CCol sm="8" lg="4">
      <Card>
        <div className="text-center">
        <img src={require('../../img/moneyGram.png')} width="32%" className="pt-3" />
        <p className="font-weight-bold text-center">MoneyGram</p>
        </div>

      </Card>
      </CCol>
      <CCol sm="8" lg="4">
      <Card>
        <div className="text-center">
        <img src={require('../../img/ria.png')} width="45%" className="pt-3" />
        <p className="font-weight-bold text-center">RIA</p>
        </div>
      
      </Card>
      </CCol>
     
    </CRow>
  )
}

export default WidgetsRemittance
