import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsDropdown = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/001-wallet.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Fund Wallet</p>
        </div>
   
      </Card>
      </CCol>
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/002-money.png')} width="15%" className="pt-3 text-info" />
        <p className="font-weight-bold text-center" >Send Money (Nigeria)</p>
        </div>
     
      </Card>
      </CCol>
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/002-money.png')} width="15%" className="pt-3 text-info" />
        <p className="font-weight-bold text-center" >Send Money (Africa)</p>
        </div>
     
      </Card>
      </CCol>
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/006-credit-card.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Get a GO Card </p>
        </div>
   
      </Card>
      </CCol>

      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/005-call.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Buy Airtime </p>
        </div>
   
      </Card>
      </CCol>

      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/003-list.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Buy Data Bundle </p>
        </div>
   
      </Card>
      </CCol>
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/001-tv-monitor.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Subscribe Cable TV</p>
        </div>

      </Card>
      </CCol>
      <CCol sm="6" lg="3">
      <Card>
        <div className="text-center">
        <img src={require('../../img/002-light-bulb.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Pay Electricity Bill</p>
        </div>
      
      </Card>
      </CCol>
     
      
    </CRow>
  )
}

export default WidgetsDropdown
