import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsTaxes = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/lagosRevenue.jpg')} width="50%" className="pt-3 pb-3 text-info" />
        </div>
     
      </Card>
      </CCol>

    </CRow>
  )
}

export default WidgetsTaxes
