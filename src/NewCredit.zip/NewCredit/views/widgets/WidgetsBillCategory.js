import React from 'react'
import {
  CWidgetDropdown,
  CRow,
  CCol,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import ChartLineSimple from '../charts/ChartLineSimple'
import ChartBarSimple from '../charts/ChartBarSimple'
import {Card, CardImg} from 'reactstrap'

const WidgetsBillCategory = () => {
  // render
  return (
    <CRow>
      
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/transfer.png')} width="15%" className="pt-3 text-info" />
        <p className="font-weight-bold text-center" >Cable TV</p>
        </div>
     
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/loans.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Utility Bills</p>
        </div>

      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/bill_payment.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Internet Plans</p>
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/bill_payment.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Taxes</p>
        </div>
      
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/buy_airtime.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Schools</p>
        </div>
   
      </Card>
      </CCol>
      <CCol sm="4" lg="2">
      <Card>
        <div className="text-center">
        <img src={require('../../img/bill_payment.png')} width="15%" className="pt-3" />
        <p className="font-weight-bold text-center">Flights</p>
        </div>
      
      </Card>
      </CCol>

      
    </CRow>
  )
}

export default WidgetsBillCategory
